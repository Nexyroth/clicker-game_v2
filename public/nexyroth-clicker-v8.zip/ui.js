/**
 * NEXYROTH CLICKER - MAIN UI & GAME FEEL CONTROLLER (TASK 4.4)
 * Pure JavaScript - Object Pool for Floating Numbers - 60 FPS on Mobile WebView
 */
(function (global) {
  'use strict';

  const POOL_SIZE = 30;
  let poolElements = [];
  let poolIndex = 0;
  let floatingContainer = null;
  let coreSphereEl = null;

  // Skill cooldowns in seconds
  const skillCooldowns = {
    overload: 0,
    surge: 0,
    warp: 0
  };

  /**
   * TASK 4.4: Pre-allocate DOM elements for Floating Numbers (Object Pooling)
   * Prevents creating/destroying thousands of divs which causes GC frame drops in WebView
   */
  function initFloatingPool() {
    floatingContainer = document.getElementById('floatingNumbersLayer');
    if (!floatingContainer) return;

    floatingContainer.innerHTML = '';
    poolElements = [];

    for (let i = 0; i < POOL_SIZE; i++) {
      const el = document.createElement('div');
      el.className = 'floating-number';
      el.style.display = 'none';
      floatingContainer.appendChild(el);
      poolElements.push(el);
    }
  }

  function spawnFloatingNumber(x, y, text, isCrit) {
    if (!floatingContainer || poolElements.length === 0) return;
    const state = global.GameState.get();
    if (!state.settings.floatingNumbers) return;

    const el = poolElements[poolIndex];
    poolIndex = (poolIndex + 1) % POOL_SIZE;

    // Reset animation
    el.style.display = 'none';
    void el.offsetWidth; // Trigger reflow to restart css animation

    const scatterX = (Math.random() - 0.5) * 50;
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.style.setProperty('--scatter-x', scatterX + 'px');
    el.textContent = isCrit ? '★ ' + text + ' CRIT!' : '+' + text;

    if (isCrit) {
      el.classList.add('crit');
    } else {
      el.classList.remove('crit');
    }

    el.style.display = 'block';

    setTimeout(function () {
      el.style.display = 'none';
    }, 850);
  }

  function spawnRipple(x, y) {
    if (!coreSphereEl) return;
    const state = global.GameState.get();
    if (!state.settings.particles) return;

    const ripple = document.createElement('div');
    ripple.className = 'ripple-wave';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    coreSphereEl.appendChild(ripple);

    setTimeout(function () {
      if (ripple.parentNode) {
        ripple.parentNode.removeChild(ripple);
      }
    }, 600);
  }

  /**
   * Stat Calculations: Click Power, CPS, Crits, Multipliers
   */
  function calculateStats() {
    const state = global.GameState.get();
    let rawClick = 1;
    let rawCps = 0;

    state.upgrades.forEach(function (u) {
      if (u.effectType === 'click') {
        rawClick += u.level * u.baseEffect;
      } else {
        rawCps += u.level * u.baseEffect;
      }
    });

    let skillClickMult = 1;
    let skillCpsMult = 1;
    let critChance = 0.05;
    let critMult = 2.0;

    state.skills.forEach(function (s) {
      if (s.unlocked) {
        if (s.effectType === 'clickPower') skillClickMult += s.effectValue;
        if (s.effectType === 'cps') skillCpsMult += s.effectValue;
        if (s.effectType === 'critChance') critChance += s.effectValue;
        if (s.id === 'chrono_crit_1') critMult += 1.0;
      }
    });

    let relicClickMult = 1;
    let relicCpsMult = 1;
    let relicCrit = 0;

    state.relics.forEach(function (r) {
      if (r.equipped) {
        relicClickMult += r.clickBonus;
        relicCpsMult += r.cpsBonus;
        relicCrit += r.critBonus;
      }
    });

    let permanentMult = 1;
    const multItem = state.gemShopItems.find(function (i) { return i.id === 'gem_mult_1'; });
    if (multItem && multItem.purchased) permanentMult *= 2;

    const critOverload = state.gemShopItems.find(function (i) { return i.id === 'gem_crit_overload'; });
    if (critOverload && critOverload.purchased) {
      critChance += 0.1;
      critMult += 2.0;
    }

    const prestigeMult = 1 + (state.astralShards * 0.01);

    let frenzyMult = 1;
    state.activeBoosts.forEach(function (b) {
      frenzyMult *= b.multiplier;
    });

    const finalClick = Math.max(1, Math.floor(rawClick * skillClickMult * relicClickMult * permanentMult * prestigeMult));
    const finalCps = Math.max(0, Math.floor(rawCps * skillCpsMult * relicCpsMult * permanentMult * prestigeMult));

    return {
      clickPower: finalClick,
      cps: finalCps,
      critChance: Math.min(0.85, critChance + relicCrit),
      critMultiplier: critMult,
      frenzyMultiplier: frenzyMult
    };
  }

  function updateStatsDisplay() {
    const state = global.GameState.get();
    const stats = calculateStats();
    const sci = state.settings.scientificNotation;

    // Header stats
    const essenceEl = document.getElementById('headerEssence');
    const shardsEl = document.getElementById('headerShards');
    const gemsEl = document.getElementById('headerGems');

    if (essenceEl) essenceEl.textContent = global.Numeric.formatNumber(state.essence, sci);
    if (shardsEl) shardsEl.textContent = global.Numeric.formatNumber(state.astralShards, sci);
    if (gemsEl) gemsEl.textContent = state.astralGems.toLocaleString();

    // Center Core rates
    const coreClickRateEl = document.getElementById('coreClickRate');
    const coreCritRateEl = document.getElementById('coreCritRate');
    if (coreClickRateEl) coreClickRateEl.textContent = '+' + global.Numeric.formatNumber(stats.clickPower * stats.frenzyMultiplier, sci);
    if (coreCritRateEl) coreCritRateEl.textContent = (stats.critChance * 100).toFixed(1) + '% (' + stats.critMultiplier + 'x)';

    // Left Panel stats
    const panelLevelEl = document.getElementById('panelLevel');
    const panelExpText = document.getElementById('panelExpText');
    const panelExpBar = document.getElementById('panelExpBar');
    const panelClickPower = document.getElementById('panelClickPower');
    const panelCps = document.getElementById('panelCps');
    const skillPointsBanner = document.getElementById('skillPointsBanner');
    const skillPointsCount = document.getElementById('skillPointsCount');

    if (panelLevelEl) panelLevelEl.textContent = 'Level ' + state.level;
    if (panelExpText) {
      const pct = Math.min(100, Math.floor((state.currentExp / state.maxExp) * 100));
      panelExpText.textContent = state.currentExp + ' / ' + state.maxExp + ' EXP (' + pct + '%)';
      if (panelExpBar) panelExpBar.style.width = pct + '%';
    }
    if (panelClickPower) panelClickPower.textContent = global.Numeric.formatNumber(stats.clickPower * stats.frenzyMultiplier, sci);
    if (panelCps) panelCps.textContent = global.Numeric.formatNumber(stats.cps * stats.frenzyMultiplier, sci) + '/s';

    if (skillPointsBanner && skillPointsCount) {
      if (state.skillPoints > 0) {
        skillPointsBanner.style.display = 'flex';
        skillPointsCount.textContent = '+' + state.skillPoints;
      } else {
        skillPointsBanner.style.display = 'none';
      }
    }
  }

  /**
   * Core Interactive Click Handler with Juice
   */
  function initCoreInteractions() {
    coreSphereEl = document.getElementById('nexyrothCore');
    if (!coreSphereEl) return;

    function handlePressStart() {
      coreSphereEl.classList.add('is-pressing');
    }
    function handlePressEnd() {
      coreSphereEl.classList.remove('is-pressing');
    }

    coreSphereEl.addEventListener('mousedown', handlePressStart);
    coreSphereEl.addEventListener('mouseup', handlePressEnd);
    coreSphereEl.addEventListener('mouseleave', handlePressEnd);

    coreSphereEl.addEventListener('touchstart', handlePressStart, { passive: true });
    coreSphereEl.addEventListener('touchend', handlePressEnd, { passive: true });

    coreSphereEl.addEventListener('click', function (e) {
      const stats = calculateStats();
      const isCrit = Math.random() < stats.critChance;
      const baseGain = stats.clickPower * stats.frenzyMultiplier;
      const gain = isCrit ? baseGain * stats.critMultiplier : baseGain;

      global.Sound.playClick(isCrit);

      const state = global.GameState.get();
      state.essence += gain;
      state.totalEssence += gain;
      state.totalClicks += 1;

      // EXP progression
      state.currentExp += 1;
      if (state.currentExp >= state.maxExp) {
        state.level += 1;
        state.currentExp = 0;
        state.maxExp = Math.floor(state.maxExp * 1.35);
        state.skillPoints += 1;
        global.Sound.playLevelUp();
      }

      // Coordinates
      const rect = coreSphereEl.getBoundingClientRect();
      const clientX = e.clientX || (rect.left + rect.width / 2);
      const clientY = e.clientY || (rect.top + rect.height / 2);
      const relX = clientX - rect.left;
      const relY = clientY - rect.top;

      spawnRipple(relX, relY);
      spawnFloatingNumber(relX, relY, global.Numeric.formatNumber(gain, state.settings.scientificNotation), isCrit);

      updateStatsDisplay();
      if (global.UIUpgrades && global.UIUpgrades.render) {
        global.UIUpgrades.render();
      }
    });
  }

  /**
   * Quick Skills Handlers
   */
  function initSkillsQuickbar() {
    const overloadBtn = document.getElementById('skillOverloadBtn');
    const surgeBtn = document.getElementById('skillSurgeBtn');
    const warpBtn = document.getElementById('skillWarpBtn');

    if (overloadBtn) {
      overloadBtn.addEventListener('click', function () {
        if (skillCooldowns.overload > 0) return;
        global.Sound.playPurchase();
        skillCooldowns.overload = 45;
        const state = global.GameState.get();
        state.activeBoosts.push({
          id: 'skill_overload',
          name: 'Void Overload',
          multiplier: 3,
          remainingSeconds: 15
        });
        updateStatsDisplay();
      });
    }

    if (surgeBtn) {
      surgeBtn.addEventListener('click', function () {
        if (skillCooldowns.surge > 0) return;
        global.Sound.playLevelUp();
        skillCooldowns.surge = 60;
        const stats = calculateStats();
        const instantGain = stats.cps * 30;
        const state = global.GameState.get();
        state.essence += instantGain;
        state.totalEssence += instantGain;
        updateStatsDisplay();
      });
    }

    if (warpBtn) {
      warpBtn.addEventListener('click', function () {
        if (skillCooldowns.warp > 0) return;
        global.Sound.playPurchase();
        skillCooldowns.warp = 90;
        const state = global.GameState.get();
        state.activeBoosts.push({
          id: 'skill_warp',
          name: 'Time Warp',
          multiplier: 2,
          remainingSeconds: 20
        });
        updateStatsDisplay();
      });
    }
  }

  function updateCooldowns(dt) {
    ['overload', 'surge', 'warp'].forEach(function (key) {
      if (skillCooldowns[key] > 0) {
        skillCooldowns[key] = Math.max(0, parseFloat((skillCooldowns[key] - dt).toFixed(1)));
        const overlay = document.getElementById(key + 'CdOverlay');
        const btn = document.getElementById('skill' + key.charAt(0).toUpperCase() + key.slice(1) + 'Btn');
        if (overlay) {
          if (skillCooldowns[key] > 0) {
            overlay.style.display = 'flex';
            overlay.textContent = skillCooldowns[key] + 's';
            if (btn) btn.disabled = true;
          } else {
            overlay.style.display = 'none';
            if (btn) btn.disabled = false;
          }
        }
      }
    });
  }

  /**
   * Offline Progress Welcome Back Banner
   */
  function checkOfflineGain() {
    const state = global.GameState.get();
    const now = Date.now();
    const lastSave = state.lastSaveTime || now;
    const diffSec = Math.floor((now - lastSave) / 1000);

    if (diffSec > 15) {
      const stats = calculateStats();
      const hasOfflineBonus = state.gemShopItems.some(function (i) { return i.id === 'gem_offline_boost' && i.purchased; });
      const efficiency = hasOfflineBonus ? 1.0 : 0.5;
      const gain = Math.floor(stats.cps * diffSec * efficiency);

      if (gain > 0) {
        state.essence += gain;
        state.totalEssence += gain;
        state.lastSaveTime = now;

        const banner = document.getElementById('offlineToast');
        const msg = document.getElementById('offlineToastMsg');
        if (banner && msg) {
          msg.textContent = 'While away for ' + Math.floor(diffSec / 60) + ' min, your conduits harvested +' + global.Numeric.formatNumber(gain, state.settings.scientificNotation) + ' Cosmic Essence!';
          banner.style.display = 'flex';
        }
      }
    }
  }

  function init() {
    initFloatingPool();
    initCoreInteractions();
    initSkillsQuickbar();
    checkOfflineGain();
    updateStatsDisplay();

    // Offline toast claim button
    const claimBtn = document.getElementById('offlineClaimBtn');
    if (claimBtn) {
      claimBtn.addEventListener('click', function () {
        const banner = document.getElementById('offlineToast');
        if (banner) banner.style.display = 'none';
      });
    }

    // Modal Triggers
    const bindBtn = function (btnId, modalId) {
      const btn = document.getElementById(btnId);
      if (btn) {
        btn.addEventListener('click', function () {
          global.UIModals.open(modalId);
        });
      }
    };

    bindBtn('headerGemShopBtn', 'gemShopModal');
    bindBtn('headerSettingsBtn', 'settingsModal');
    bindBtn('openBossBtn', 'bossModal');
    bindBtn('openSkillsBtn', 'skillsModal');
    bindBtn('openSkillsLink', 'skillsModal');
    bindBtn('openInventoryBtn', 'inventoryModal');
    bindBtn('openPrestigeBtn', 'prestigeModal');
    bindBtn('openAchievementsBtn', 'achievementsModal');
  }

  global.UI = {
    init: init,
    calculateStats: calculateStats,
    updateStatsDisplay: updateStatsDisplay,
    updateCooldowns: updateCooldowns
  };
})(typeof window !== 'undefined' ? window : this);
