import fs from 'fs';
import path from 'path';

// CRC-32 table
const crcTable = (() => {
  let c;
  const table = [];
  for (let n = 0; n < 256; n++) {
    c = n;
    for (let k = 0; k < 8; k++) {
      c = ((c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1));
    }
    table[n] = c;
  }
  return table;
})();

function crc32(buffer) {
  let crc = 0 ^ (-1);
  for (let i = 0; i < buffer.length; i++) {
    crc = (crc >>> 8) ^ crcTable[(crc ^ buffer[i]) & 0xFF];
  }
  return (crc ^ (-1)) >>> 0;
}

function buildZip(files) {
  const fileEntries = [];
  let localHeadersOffset = 0;

  files.forEach((f) => {
    const nameBytes = Buffer.from(f.name, 'utf8');
    const dataBytes = Buffer.isBuffer(f.data) ? f.data : Buffer.from(f.data, 'utf8');
    const fileCrc = crc32(dataBytes);
    const uncompressedSize = dataBytes.length;

    const localHeader = Buffer.alloc(30 + nameBytes.length);
    localHeader.writeUInt32LE(0x04034b50, 0); // signature
    localHeader.writeUInt16LE(20, 4);         // version needed
    localHeader.writeUInt16LE(0, 6);          // flags
    localHeader.writeUInt16LE(0, 8);          // compression (store)
    localHeader.writeUInt16LE(0, 10);         // mod time
    localHeader.writeUInt16LE(0, 12);         // mod date
    localHeader.writeUInt32LE(fileCrc, 14);    // crc32
    localHeader.writeUInt32LE(uncompressedSize, 18); // comp size
    localHeader.writeUInt32LE(uncompressedSize, 22); // uncomp size
    localHeader.writeUInt16LE(nameBytes.length, 26); // name length
    localHeader.writeUInt16LE(0, 28);         // extra len
    nameBytes.copy(localHeader, 30);

    fileEntries.push({
      nameBytes,
      dataBytes,
      localHeader,
      crc: fileCrc,
      size: uncompressedSize,
      offset: localHeadersOffset,
    });

    localHeadersOffset += localHeader.length + dataBytes.length;
  });

  const centralDirectoryEntries = [];
  let centralDirSize = 0;

  fileEntries.forEach((entry) => {
    const cdHeader = Buffer.alloc(46 + entry.nameBytes.length);
    cdHeader.writeUInt32LE(0x02014b50, 0); // signature
    cdHeader.writeUInt16LE(20, 4);         // version made by
    cdHeader.writeUInt16LE(20, 6);         // version needed
    cdHeader.writeUInt16LE(0, 8);          // flags
    cdHeader.writeUInt16LE(0, 10);         // compression
    cdHeader.writeUInt16LE(0, 12);         // mod time
    cdHeader.writeUInt16LE(0, 14);         // mod date
    cdHeader.writeUInt32LE(entry.crc, 16); // crc32
    cdHeader.writeUInt32LE(entry.size, 20);// comp size
    cdHeader.writeUInt32LE(entry.size, 24);// uncomp size
    cdHeader.writeUInt16LE(entry.nameBytes.length, 28); // name len
    cdHeader.writeUInt16LE(0, 30);         // extra len
    cdHeader.writeUInt16LE(0, 32);         // comment len
    cdHeader.writeUInt16LE(0, 34);         // disk start
    cdHeader.writeUInt16LE(0, 36);         // internal attr
    cdHeader.writeUInt32LE(0, 38);         // external attr
    cdHeader.writeUInt32LE(entry.offset, 42); // offset
    entry.nameBytes.copy(cdHeader, 46);

    centralDirectoryEntries.push(cdHeader);
    centralDirSize += cdHeader.length;
  });

  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); // signature
  eocd.writeUInt16LE(0, 4);          // disk num
  eocd.writeUInt16LE(0, 6);          // disk with CD
  eocd.writeUInt16LE(files.length, 8); // entries this disk
  eocd.writeUInt16LE(files.length, 10); // total entries
  eocd.writeUInt32LE(centralDirSize, 12); // size CD
  eocd.writeUInt32LE(localHeadersOffset, 16); // offset CD
  eocd.writeUInt16LE(0, 20);         // comment len

  const parts = [];
  fileEntries.forEach((e) => {
    parts.push(e.localHeader);
    parts.push(e.dataBytes);
  });
  centralDirectoryEntries.forEach((c) => {
    parts.push(c);
  });
  parts.push(eocd);

  return Buffer.concat(parts);
}

function getAllFiles(dir, prefix = '') {
  const result = [];
  const list = fs.readdirSync(dir, { withFileTypes: true });
  for (const item of list) {
    if (item.name.startsWith('.') || item.name === 'node_modules' || item.name === 'dist') continue;
    const relPath = prefix ? `${prefix}/${item.name}` : item.name;
    const fullPath = path.join(dir, item.name);
    if (item.isDirectory()) {
      result.push(...getAllFiles(fullPath, relPath));
    } else if (item.isFile() && !item.name.endsWith('.zip')) {
      result.push({ name: relPath, fullPath });
    }
  }
  return result;
}

const root = process.cwd();
const filesToPack = getAllFiles(root);
const files = [];

for (const f of filesToPack) {
  const data = fs.readFileSync(f.fullPath);
  files.push({ name: f.name, data });
}

console.log(`Packing ${files.length} files into zip...`);
const zipBuffer = buildZip(files);

fs.writeFileSync(path.join(root, 'public', 'nexyroth-clicker-v8.zip'), zipBuffer);
fs.writeFileSync(path.join(root, 'public', 'nexyroth-clicker-phase4.zip'), zipBuffer);
fs.writeFileSync(path.join(root, 'nexyroth-clicker-v8.zip'), zipBuffer);
fs.writeFileSync(path.join(root, 'nexyroth-clicker-phase4.zip'), zipBuffer);

console.log(`Created zip archives! Size: ${(zipBuffer.length / (1024 * 1024)).toFixed(2)} MB`);
