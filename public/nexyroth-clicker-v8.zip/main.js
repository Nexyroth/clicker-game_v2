/**
 * NEXYROTH CLICKER - MAIN GAME LOOP CONTROLLER
 * Pure JavaScript - 100% Offline, Zero Server Dependency
 */
(function (global) {
  'use strict';

  function initGame() {
    // 1. Load persisted game state
    global.GameState.load();

    // 2. Initialize modules
    if (global.UIModals) global.UIModals.init();
    if (global.UI) global.UI.init();
    if (global.UIUpgrades) global.UIUpgrades.init();

    // 3. Start 100ms core game tick loop
    setInterval(gameTick, 100);

    // 4. Auto-save every 5 seconds
    setInterval(function () {
      global.GameState.save();
    }, 5000);
  }

  function gameTick() {
    const state = global.GameState.get();
    const stats = global.UI.calculateStats();

    // 1. Passive CPS generation (dt = 0.1s)
    const tickGain = (stats.cps * stats.frenzyMultiplier) / 10;
    if (tickGain > 0) {
      state.essence += tickGain;
      state.totalEssence += tickGain;
    }

    // 2. Countdown active boosts
    if (state.activeBoosts.length > 0) {
      state.activeBoosts = state.activeBoosts.map(function (b) {
        return Object.assign({}, b, { remainingSeconds: b.remainingSeconds - 0.1 });
      }).filter(function (b) {
        return b.remainingSeconds > 0;
      });
    }

    // 3. Countdown Boss battle timer if active
    const boss = global.GameState.getBoss();
    if (boss && boss.active) {
      boss.remainingTime = Math.max(0, parseFloat((boss.remainingTime - 0.1).toFixed(1)));
      if (boss.remainingTime <= 0) {
        boss.active = false;
        boss.currentHp = boss.maxHp;
        boss.remainingTime = boss.timeLimit;
        global.Sound.playError();
      }
    }

    // 4. Update Skill Cooldowns
    global.UI.updateCooldowns(0.1);

    // 5. Update UI stats display
    global.UI.updateStatsDisplay();

    // 6. Update achievements
    updateAchievementsProgress();
  }

  function updateAchievementsProgress() {
    const state = global.GameState.get();
    state.achievements.forEach(function (ach) {
      if (ach.type === 'clicks') ach.current = state.totalClicks;
      if (ach.type === 'essence') ach.current = Math.floor(state.totalEssence);
      if (ach.type === 'level') ach.current = state.level;
      if (ach.type === 'bosses') ach.current = state.bossesDefeated;
      if (ach.type === 'prestige') ach.current = state.prestigeCount;
    });
  }

  // Launch when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initGame);
  } else {
    initGame();
  }

  global.Main = {
    init: initGame
  };
})(typeof window !== 'undefined' ? window : this);
