/**
 * NEXYROTH CLICKER - UI UPGRADES MODULE (TASK 4.2: COLUMN RIGHT TOP PRIORITY)
 * Pure JavaScript
 */
(function (global) {
  'use strict';

  let currentMultiplier = 1; // 1, 10, 25, 100, or 'MAX'

  const ICON_SVGS = {
    zap: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
    sparkles: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>',
    'cloud-lightning': '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 16.326A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 .5 8.973"/><path d="m13 12-3 5h4l-3 5"/></svg>',
    flame: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>',
    disc: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/></svg>',
    atom: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="1"/><path d="M20.2 20.2c2.04-2.03.02-7.36-4.5-11.9-4.54-4.52-9.87-6.54-11.9-4.5-2.04 2.03-.02 7.36 4.5 11.9 4.54 4.52 9.87 6.54 11.9 4.5Z"/><path d="M15.7 8.3c4.52-4.54 6.54-9.87 4.5-11.9-2.03-2.04-7.36-.02-11.9 4.5-4.52 4.54-6.54 9.87-4.5 11.9 2.03 2.04 7.36.02 11.9-4.5Z"/></svg>',
    orbit: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M12 21a9 9 0 0 0 9-9 9 9 0 0 0-9-9 9 9 0 0 0-9 9 9 9 0 0 0 9 9Z"/></svg>',
    sun: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>',
    clock: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
    shield: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/></svg>'
  };

  function setMultiplier(val) {
    currentMultiplier = val;
    document.querySelectorAll('.multiplier-btn').forEach(function (btn) {
      if (btn.dataset.mult === String(val)) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
    renderUpgradesList();
  }

  function renderUpgradesList() {
    const listEl = document.getElementById('upgradesList');
    if (!listEl) return;

    const state = global.GameState.get();
    const essence = state.essence;
    const playerLevel = state.level;
    const scientific = state.settings.scientificNotation;

    listEl.innerHTML = '';

    state.upgrades.forEach(function (upg) {
      const isUnlocked = playerLevel >= upg.unlockedAtLevel;
      const card = document.createElement('div');
      card.className = 'upgrade-card';

      if (!isUnlocked) {
        card.classList.add('cant-afford');
        card.innerHTML = `
          <div class="upgrade-info" style="opacity: 0.6;">
            <div class="upgrade-icon-box" style="background: rgba(30,41,59,0.5); border: 1px solid rgba(71,85,105,0.4); color: #64748b;">
              ${ICON_SVGS.shield}
            </div>
            <div class="upgrade-details">
              <div class="upgrade-name" style="color: #94a3b8;">Locked Conduit</div>
              <div class="upgrade-effect">Unlocks at Level ${upg.unlockedAtLevel}</div>
            </div>
          </div>
        `;
        listEl.appendChild(card);
        return;
      }

      let countToBuy = 1;
      let cost = 0;
      let canAfford = false;

      if (currentMultiplier === 'MAX') {
        const maxInfo = global.Numeric.calculateMaxAffordable(upg.baseCost, upg.costMultiplier, upg.level, essence);
        countToBuy = maxInfo.count > 0 ? maxInfo.count : 1;
        cost = maxInfo.count > 0 ? maxInfo.totalCost : global.Numeric.calculateUpgradeCost(upg.baseCost, upg.costMultiplier, upg.level, 1);
        canAfford = maxInfo.count > 0 && essence >= cost;
      } else {
        countToBuy = Number(currentMultiplier);
        cost = global.Numeric.calculateUpgradeCost(upg.baseCost, upg.costMultiplier, upg.level, countToBuy);
        canAfford = essence >= cost;
      }

      if (canAfford) {
        card.classList.add('can-afford');
      } else {
        card.classList.add('cant-afford');
      }

      const totalEffect = upg.level * upg.baseEffect;
      const nextEffect = countToBuy * upg.baseEffect;
      const iconSvg = ICON_SVGS[upg.icon] || ICON_SVGS.zap;
      const isClick = upg.effectType === 'click';

      card.innerHTML = `
        <div class="upgrade-info">
          <div class="upgrade-icon-box" style="${isClick ? 'background: rgba(120,53,15,0.3); border: 1px solid rgba(245,158,11,0.3); color: #fde047;' : 'background: rgba(8,47,73,0.4); border: 1px solid rgba(56,189,248,0.3); color: #38bdf8;'}">
            ${iconSvg}
          </div>
          <div class="upgrade-details">
            <div class="upgrade-name-row">
              <span class="upgrade-name">${upg.name}</span>
              <span class="upgrade-level-badge">Lv.${upg.level}</span>
            </div>
            <div class="upgrade-effect">
              ${isClick ? 'Click' : 'CPS'}: <strong style="color: #f1f5f9;">+${global.Numeric.formatNumber(totalEffect, scientific)}</strong>
              <span style="color: #34d399; font-weight: 700; margin-left: 4px;">(+${global.Numeric.formatNumber(nextEffect, scientific)})</span>
            </div>
          </div>
        </div>
        <button class="upgrade-buy-btn nx-btn ${canAfford ? 'nx-btn-primary' : ''}" ${!canAfford ? 'disabled' : ''}>
          <span style="font-size: 0.625rem; font-weight: normal; opacity: 0.85;">+${countToBuy}</span>
          <span style="font-family: ui-monospace, monospace;">${global.Numeric.formatNumber(cost, scientific)}</span>
        </button>
      `;

      const buyBtn = card.querySelector('.upgrade-buy-btn');
      if (buyBtn && canAfford) {
        buyBtn.addEventListener('click', function (e) {
          e.stopPropagation();
          state.essence -= cost;
          upg.level += countToBuy;
          global.Sound.playPurchase();
          renderUpgradesList();
          if (global.UI && global.UI.updateStatsDisplay) {
            global.UI.updateStatsDisplay();
          }
        });
      }

      listEl.appendChild(card);
    });
  }

  function init() {
    document.querySelectorAll('.multiplier-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        const mult = btn.dataset.mult === 'MAX' ? 'MAX' : Number(btn.dataset.mult);
        setMultiplier(mult);
      });
    });
    renderUpgradesList();
  }

  global.UIUpgrades = {
    init: init,
    render: renderUpgradesList,
    setMultiplier: setMultiplier
  };
})(typeof window !== 'undefined' ? window : this);
