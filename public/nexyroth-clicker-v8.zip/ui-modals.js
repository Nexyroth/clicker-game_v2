/**
 * NEXYROTH CLICKER - UI MODALS MODULE (TASK 4.1 & TASK 4.3)
 * Pure JavaScript - Handles Settings, Gem Shop, Boss, Skills, Inventory, Prestige, Achievements
 */
(function (global) {
  'use strict';

  function openModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    modal.classList.add('is-open');
    if (id === 'gemShopModal') renderGemShop();
    if (id === 'bossModal') renderBossModal();
    if (id === 'skillsModal') renderSkillsModal();
    if (id === 'inventoryModal') renderInventoryModal();
    if (id === 'prestigeModal') renderPrestigeModal();
    if (id === 'achievementsModal') renderAchievementsModal();
  }

  function closeModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    modal.classList.remove('is-open');
  }

  function closeAllModals() {
    document.querySelectorAll('.nx-modal-backdrop').forEach(function (m) {
      m.classList.remove('is-open');
    });
  }

  // TASK 4.1: Close on backdrop click & close button
  function initModals() {
    document.querySelectorAll('.nx-modal-backdrop').forEach(function (backdrop) {
      backdrop.addEventListener('click', function (e) {
        if (e.target === backdrop) {
          backdrop.classList.remove('is-open');
        }
      });
      const closeBtn = backdrop.querySelector('.nx-modal-close');
      if (closeBtn) {
        closeBtn.addEventListener('click', function () {
          backdrop.classList.remove('is-open');
        });
      }
    });

    // TASK 4.1: Close on Escape key
    // TASK 4.3: Toggle Gem Shop on 'G' key (unless typing in input/textarea)
    window.addEventListener('keydown', function (e) {
      const activeTag = document.activeElement ? document.activeElement.tagName.toUpperCase() : '';
      const isInput = activeTag === 'INPUT' || activeTag === 'TEXTAREA' || (document.activeElement && document.activeElement.isContentEditable);

      if (e.key === 'Escape') {
        closeAllModals();
      } else if ((e.key === 'g' || e.key === 'G') && !isInput) {
        const gemModal = document.getElementById('gemShopModal');
        if (gemModal) {
          if (gemModal.classList.contains('is-open')) {
            closeModal('gemShopModal');
          } else {
            openModal('gemShopModal');
          }
        }
      }
    });

    initSettingsModal();
    initGemShopModal();
  }

  /* ------------------------------------------------------------
     SETTINGS MODAL
     ------------------------------------------------------------ */
  function initSettingsModal() {
    const sfxToggle = document.getElementById('sfxToggle');
    const sfxVolume = document.getElementById('sfxVolume');
    const sciToggle = document.getElementById('sciToggle');
    const floatToggle = document.getElementById('floatToggle');
    const manualSaveBtn = document.getElementById('manualSaveBtn');
    const exportBtn = document.getElementById('exportSaveBtn');
    const importInput = document.getElementById('importSaveInput');
    const hardResetBtn = document.getElementById('hardResetBtn');

    if (sfxToggle) {
      sfxToggle.addEventListener('click', function () {
        const state = global.GameState.get();
        state.settings.sfxEnabled = !state.settings.sfxEnabled;
        sfxToggle.classList.toggle('is-active', state.settings.sfxEnabled);
        global.Sound.setEnabled(state.settings.sfxEnabled);
      });
    }

    if (sfxVolume) {
      sfxVolume.addEventListener('input', function (e) {
        const vol = parseFloat(e.target.value);
        global.GameState.get().settings.sfxVolume = vol;
        global.Sound.setVolume(vol);
      });
    }

    if (sciToggle) {
      sciToggle.addEventListener('click', function () {
        const state = global.GameState.get();
        state.settings.scientificNotation = !state.settings.scientificNotation;
        sciToggle.classList.toggle('is-active', state.settings.scientificNotation);
        if (global.UI && global.UI.updateStatsDisplay) global.UI.updateStatsDisplay();
        if (global.UIUpgrades && global.UIUpgrades.render) global.UIUpgrades.render();
      });
    }

    if (floatToggle) {
      floatToggle.addEventListener('click', function () {
        const state = global.GameState.get();
        state.settings.floatingNumbers = !state.settings.floatingNumbers;
        floatToggle.classList.toggle('is-active', state.settings.floatingNumbers);
      });
    }

    if (manualSaveBtn) {
      manualSaveBtn.addEventListener('click', function () {
        global.GameState.save();
        global.Sound.playPurchase();
        manualSaveBtn.textContent = 'Saved!';
        setTimeout(function () { manualSaveBtn.textContent = 'Save Progress'; }, 1500);
      });
    }

    if (exportBtn) {
      exportBtn.addEventListener('click', function () {
        const json = JSON.stringify(global.GameState.get(), null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'nexyroth_save_' + Date.now() + '.json';
        a.click();
        URL.revokeObjectURL(url);
      });
    }

    if (importInput) {
      importInput.addEventListener('change', function (e) {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function (ev) {
          try {
            const parsed = JSON.parse(ev.target.result);
            if (parsed.version) {
              global.GameState.set(parsed);
              global.GameState.save();
              global.Sound.playLevelUp();
              closeAllModals();
              if (global.UI && global.UI.updateStatsDisplay) global.UI.updateStatsDisplay();
              if (global.UIUpgrades && global.UIUpgrades.render) global.UIUpgrades.render();
            }
          } catch (err) {
            global.Sound.playError();
          }
        };
        reader.readAsText(file);
      });
    }

    if (hardResetBtn) {
      hardResetBtn.addEventListener('click', function () {
        if (confirm('Are you sure you want to HARD RESET? All local progress, upgrades, and relics will be wiped!')) {
          global.GameState.reset();
          global.Sound.playError();
          closeAllModals();
          if (global.UI && global.UI.updateStatsDisplay) global.UI.updateStatsDisplay();
          if (global.UIUpgrades && global.UIUpgrades.render) global.UIUpgrades.render();
        }
      });
    }
  }

  /* ------------------------------------------------------------
     TASK 4.3: GEM SHOP MODAL & REDEEM CODES
     ------------------------------------------------------------ */
  function initGemShopModal() {
    const redeemForm = document.getElementById('redeemCodeForm');
    const codeInput = document.getElementById('redeemCodeInput');
    const feedbackEl = document.getElementById('redeemFeedback');

    if (redeemForm && codeInput) {
      redeemForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const code = codeInput.value.trim().toUpperCase();
        if (!code) return;

        const state = global.GameState.get();
        if (state.redeemedCodes.indexOf(code) !== -1) {
          showFeedback('Code already redeemed!', true);
          global.Sound.playError();
          return;
        }

        const CODES = {
          NEXYROTH2026: 100,
          COSMICVOID: 75,
          PHASE4: 50,
          LUCKYGEM: 25
        };

        if (CODES[code]) {
          const reward = CODES[code];
          state.astralGems += reward;
          state.redeemedCodes.push(code);
          global.Sound.playLevelUp();
          showFeedback('Code accepted! Claimed +' + reward + ' Astral Gems!', false);
          codeInput.value = '';
          renderGemShop();
          if (global.UI && global.UI.updateStatsDisplay) global.UI.updateStatsDisplay();
        } else {
          global.Sound.playError();
          showFeedback('Invalid code. Check for typos!', true);
        }
      });
    }

    function showFeedback(msg, isError) {
      if (!feedbackEl) return;
      feedbackEl.style.display = 'block';
      feedbackEl.style.color = isError ? '#f43f5e' : '#34d399';
      feedbackEl.textContent = msg;
      setTimeout(function () { feedbackEl.style.display = 'none'; }, 3500);
    }
  }

  function renderGemShop() {
    const container = document.getElementById('gemShopItemsList');
    const gemBalanceEl = document.getElementById('gemShopBalance');
    if (!container) return;

    const state = global.GameState.get();
    if (gemBalanceEl) gemBalanceEl.textContent = state.astralGems.toLocaleString() + ' Gems';

    container.innerHTML = '';
    state.gemShopItems.forEach(function (item) {
      const canAfford = state.astralGems >= item.costGems;
      const card = document.createElement('div');
      card.className = 'nx-card';
      card.style.padding = '0.875rem';
      card.style.display = 'flex';
      card.style.alignItems = 'center';
      card.style.justifyContent = 'space-between';
      card.style.gap = '0.75rem';

      card.innerHTML = `
        <div style="min-width: 0;">
          <div style="display: flex; align-items: center; gap: 0.5rem;">
            <strong style="color: #fff; font-size: 0.875rem;">${item.name}</strong>
            ${item.purchased ? '<span class="nx-badge" style="background: rgba(16,185,129,0.2); color: #34d399; border-color: rgba(16,185,129,0.4);">Active</span>' : ''}
          </div>
          <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 2px;">${item.desc}</div>
        </div>
        <button class="nx-btn ${item.purchased ? 'nx-btn-secondary' : canAfford ? 'nx-btn-gold' : ''}" ${item.purchased || !canAfford ? 'disabled' : ''}>
          ${item.purchased ? 'Purchased' : item.costGems + ' Gems'}
        </button>
      `;

      const btn = card.querySelector('button');
      if (btn && !item.purchased && canAfford) {
        btn.addEventListener('click', function () {
          state.astralGems -= item.costGems;
          item.purchased = true;
          global.Sound.playPurchase();
          renderGemShop();
          if (global.UI && global.UI.updateStatsDisplay) global.UI.updateStatsDisplay();
        });
      }

      container.appendChild(card);
    });
  }

  /* ------------------------------------------------------------
     BOSS ENCOUNTERS MODAL
     ------------------------------------------------------------ */
  function renderBossModal() {
    const boss = global.GameState.getBoss();
    const container = document.getElementById('bossModalContent');
    if (!container) return;

    const hpPercent = Math.max(0, Math.min(100, (boss.currentHp / boss.maxHp) * 100));
    const stats = global.UI ? global.UI.calculateStats() : { clickPower: 1, frenzyMultiplier: 1 };
    const damagePerStrike = stats.clickPower * stats.frenzyMultiplier;

    container.innerHTML = `
      <div style="text-align: center; margin-bottom: 1rem;">
        <div style="font-size: 0.6875rem; font-weight: 800; text-transform: uppercase; color: #f43f5e; letter-spacing: 0.1em;">
          Tier ${boss.level} Titan
        </div>
        <h3 style="font-size: 1.25rem; font-weight: 900; color: #fff;">${boss.name}</h3>
        <p style="font-size: 0.75rem; color: #fda4af; font-style: italic;">${boss.title}</p>
      </div>

      ${boss.active ? `
        <div style="display: flex; flex-direction: column; gap: 0.75rem;">
          <div style="display: flex; justify-content: space-between; font-size: 0.75rem; font-weight: 700;">
            <span style="color: #f43f5e;">Health</span>
            <span style="font-family: ui-monospace, monospace; color: #f1f5f9;">
              ${global.Numeric.formatNumber(boss.currentHp)} / ${global.Numeric.formatNumber(boss.maxHp)} (${hpPercent.toFixed(1)}%)
            </span>
          </div>
          <div class="nx-progress" style="height: 0.65rem;">
            <div class="nx-progress-bar" style="background: linear-gradient(to right, #f43f5e, #fbbf24); width: ${hpPercent}%;"></div>
          </div>

          <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem 0.75rem; background: rgba(15,23,42,0.8); border: 1px solid rgba(51,65,85,0.5); border-radius: 0.5rem; font-size: 0.75rem;">
            <span style="color: #fbbf24; font-weight: 700;">Time Remaining:</span>
            <strong style="font-family: ui-monospace, monospace; color: #fde047; font-size: 0.875rem;">${boss.remainingTime}s</strong>
          </div>

          <button id="bossStrikeBtn" class="nx-btn nx-btn-danger" style="padding: 1.5rem; font-size: 1rem; font-weight: 900; letter-spacing: 0.05em; margin-top: 0.5rem; display: flex; flex-direction: column; gap: 0.25rem;">
            <span>STRIKE THE TITAN!</span>
            <span style="font-size: 0.6875rem; opacity: 0.85; font-family: ui-monospace, monospace;">Deal ${global.Numeric.formatNumber(damagePerStrike)} DMG</span>
          </button>

          <button id="bossRetreatBtn" style="background: none; border: none; color: #94a3b8; font-size: 0.75rem; text-decoration: underline; cursor: pointer; margin-top: 0.25rem;">
            Retreat from Battle
          </button>
        </div>
      ` : `
        <div style="display: flex; flex-direction: column; gap: 1rem;">
          <div style="padding: 0.75rem; background: rgba(15,23,42,0.8); border: 1px solid rgba(51,65,85,0.5); border-radius: 0.75rem; font-size: 0.75rem;">
            <div style="font-weight: 800; color: #fde047; text-transform: uppercase; margin-bottom: 0.5rem;">Victory Spoils</div>
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 0.5rem; font-family: ui-monospace, monospace; text-align: center; font-weight: 700;">
              <div style="background: rgba(245,158,11,0.15); border: 1px solid rgba(245,158,11,0.3); border-radius: 0.5rem; padding: 0.4rem; color: #fbbf24;">+${boss.rewardGems} Gems</div>
              <div style="background: rgba(129,140,248,0.15); border: 1px solid rgba(129,140,248,0.3); border-radius: 0.5rem; padding: 0.4rem; color: #818cf8;">+${boss.rewardShards} Shards</div>
              <div style="background: rgba(56,189,248,0.15); border: 1px solid rgba(56,189,248,0.3); border-radius: 0.5rem; padding: 0.4rem; color: #38bdf8;">+${boss.rewardExp} EXP</div>
            </div>
          </div>

          <button id="bossSummonBtn" class="nx-btn nx-btn-danger" style="padding: 0.875rem; font-size: 0.875rem; font-weight: 800; letter-spacing: 0.05em;">
            Summon Titan & Begin Trial
          </button>
        </div>
      `}
    `;

    const strikeBtn = document.getElementById('bossStrikeBtn');
    if (strikeBtn) {
      strikeBtn.addEventListener('click', function () {
        global.Sound.playClick(true);
        boss.currentHp = Math.max(0, boss.currentHp - damagePerStrike);
        if (boss.currentHp <= 0) {
          global.Sound.playBossVictory();
          const state = global.GameState.get();
          state.astralGems += boss.rewardGems;
          state.astralShards += boss.rewardShards;
          state.totalAstralShards += boss.rewardShards;
          state.currentExp += boss.rewardExp;
          state.bossesDefeated += 1;

          // Next boss
          const presets = global.GameState.getBossPresets();
          const nextIndex = (boss.level % presets.length);
          const nextPreset = JSON.parse(JSON.stringify(presets[nextIndex]));
          global.GameState.setBoss(nextPreset);
        }
        renderBossModal();
        if (global.UI && global.UI.updateStatsDisplay) global.UI.updateStatsDisplay();
      });
    }

    const summonBtn = document.getElementById('bossSummonBtn');
    if (summonBtn) {
      summonBtn.addEventListener('click', function () {
        boss.active = true;
        boss.currentHp = boss.maxHp;
        boss.remainingTime = boss.timeLimit;
        global.Sound.playClick(true);
        renderBossModal();
      });
    }

    const retreatBtn = document.getElementById('bossRetreatBtn');
    if (retreatBtn) {
      retreatBtn.addEventListener('click', function () {
        boss.active = false;
        boss.currentHp = boss.maxHp;
        boss.remainingTime = boss.timeLimit;
        renderBossModal();
      });
    }
  }

  /* ------------------------------------------------------------
     SKILLS MODAL
     ------------------------------------------------------------ */
  function renderSkillsModal() {
    const container = document.getElementById('skillsModalContent');
    const pointsEl = document.getElementById('skillPointsBadge');
    if (!container) return;

    const state = global.GameState.get();
    if (pointsEl) pointsEl.textContent = state.skillPoints + ' pts';

    container.innerHTML = '';
    state.skills.forEach(function (skill) {
      const hasReq = !skill.reqSkillId || state.skills.some(function (s) { return s.id === skill.reqSkillId && s.unlocked; });
      const canUnlock = !skill.unlocked && hasReq && state.skillPoints >= skill.costPoints;

      const card = document.createElement('div');
      card.className = 'nx-card';
      card.style.padding = '0.875rem';
      card.style.display = 'flex';
      card.style.alignItems = 'center';
      card.style.justifyContent = 'space-between';
      card.style.gap = '0.75rem';
      card.style.opacity = skill.unlocked ? '1' : hasReq ? '0.9' : '0.5';

      card.innerHTML = `
        <div>
          <div style="display: flex; align-items: center; gap: 0.5rem;">
            <strong style="color: #fff; font-size: 0.8125rem;">${skill.name}</strong>
            <span class="nx-badge" style="text-transform: uppercase;">${skill.branch}</span>
          </div>
          <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 2px;">${skill.description}</div>
        </div>
        <button class="nx-btn ${skill.unlocked ? 'nx-btn-secondary' : canUnlock ? 'nx-btn-primary' : ''}" ${skill.unlocked || !canUnlock ? 'disabled' : ''}>
          ${skill.unlocked ? 'Mastered' : hasReq ? `Learn (${skill.costPoints} pt)` : 'Locked'}
        </button>
      `;

      const btn = card.querySelector('button');
      if (btn && canUnlock) {
        btn.addEventListener('click', function () {
          state.skillPoints -= skill.costPoints;
          skill.unlocked = true;
          global.Sound.playPurchase();
          renderSkillsModal();
          if (global.UI && global.UI.updateStatsDisplay) global.UI.updateStatsDisplay();
        });
      }

      container.appendChild(card);
    });
  }

  /* ------------------------------------------------------------
     INVENTORY MODAL (RELICS)
     ------------------------------------------------------------ */
  function renderInventoryModal() {
    const container = document.getElementById('inventoryModalContent');
    const badge = document.getElementById('relicsEquippedBadge');
    if (!container) return;

    const state = global.GameState.get();
    const equippedCount = state.relics.filter(function (r) { return r.equipped; }).length;
    if (badge) badge.textContent = equippedCount + ' / 3 Equipped';

    container.innerHTML = '';
    state.relics.forEach(function (relic) {
      const card = document.createElement('div');
      card.className = 'nx-card';
      card.style.padding = '0.875rem';
      card.style.display = 'flex';
      card.style.alignItems = 'center';
      card.style.justifyContent = 'space-between';
      card.style.gap = '0.75rem';

      card.innerHTML = `
        <div>
          <div style="display: flex; align-items: center; gap: 0.5rem;">
            <strong style="color: #fff; font-size: 0.8125rem;">${relic.name}</strong>
            <span class="nx-badge" style="text-transform: uppercase; color: #38bdf8;">${relic.rarity}</span>
          </div>
          <div style="font-size: 0.75rem; color: #cbd5e1; margin-top: 2px;">${relic.effectDesc}</div>
        </div>
        <button class="nx-btn ${relic.equipped ? 'nx-btn-primary' : 'nx-btn-secondary'}" ${!relic.equipped && equippedCount >= 3 ? 'disabled' : ''}>
          ${relic.equipped ? 'Equipped' : 'Equip'}
        </button>
      `;

      const btn = card.querySelector('button');
      if (btn) {
        btn.addEventListener('click', function () {
          if (!relic.equipped && equippedCount >= 3) {
            global.Sound.playError();
            return;
          }
          relic.equipped = !relic.equipped;
          global.Sound.playPurchase();
          renderInventoryModal();
          if (global.UI && global.UI.updateStatsDisplay) global.UI.updateStatsDisplay();
        });
      }

      container.appendChild(card);
    });
  }

  /* ------------------------------------------------------------
     PRESTIGE (ASCENSION) MODAL
     ------------------------------------------------------------ */
  function renderPrestigeModal() {
    const container = document.getElementById('prestigeModalContent');
    if (!container) return;

    const state = global.GameState.get();
    const shardsToGain = Math.max(0, Math.floor(Math.sqrt(state.essence / 1000000)));
    const canPrestige = shardsToGain > 0;

    container.innerHTML = `
      <div style="text-align: center; padding: 1.25rem; background: rgba(147,51,234,0.15); border: 1px solid rgba(168,85,247,0.3); border-radius: 1rem;">
        <div style="font-size: 0.6875rem; font-weight: 800; text-transform: uppercase; color: #c084fc; letter-spacing: 0.1em;">Astral Shards to Harvest</div>
        <div style="font-size: 2rem; font-weight: 900; font-family: ui-monospace, monospace; color: #e9d5ff; margin: 0.5rem 0;">
          +${global.Numeric.formatNumber(shardsToGain)}
        </div>
        <div style="font-size: 0.75rem; color: #94a3b8;">
          Current Bonus: <strong style="color: #c084fc;">+${state.astralShards}%</strong> → Next Bonus: <strong style="color: #34d399;">+${state.astralShards + shardsToGain}%</strong>
        </div>
      </div>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; font-size: 0.6875rem;">
        <div style="padding: 0.75rem; background: rgba(15,23,42,0.6); border: 1px solid rgba(51,65,85,0.4); border-radius: 0.75rem;">
          <div style="color: #34d399; font-weight: 800; margin-bottom: 0.35rem;">✓ WHAT STAYS</div>
          <div style="color: #94a3b8; line-height: 1.4;">All Astral Shards & Gems, Relics, Permanent Shop Items, Achievements.</div>
        </div>
        <div style="padding: 0.75rem; background: rgba(15,23,42,0.6); border: 1px solid rgba(51,65,85,0.4); border-radius: 0.75rem;">
          <div style="color: #f43f5e; font-weight: 800; margin-bottom: 0.35rem;">✗ WHAT RESETS</div>
          <div style="color: #94a3b8; line-height: 1.4;">Cosmic Essence, Upgrade levels, Player Level & Exp, Active Titan encounters.</div>
        </div>
      </div>

      <button id="prestigeAscendBtn" class="nx-btn nx-btn-primary" style="padding: 0.875rem; font-weight: 800; letter-spacing: 0.05em; background: linear-gradient(135deg, #7e22ce, #a855f7);" ${!canPrestige ? 'disabled' : ''}>
        ${canPrestige ? 'Ascend to Astral Plane' : 'Need at least 1,000,000 Essence'}
      </button>
    `;

    const ascendBtn = document.getElementById('prestigeAscendBtn');
    if (ascendBtn && canPrestige) {
      ascendBtn.addEventListener('click', function () {
        state.essence = 0;
        state.astralShards += shardsToGain;
        state.totalAstralShards += shardsToGain;
        state.level = 1;
        state.currentExp = 0;
        state.maxExp = 100;
        state.skillPoints = 0;
        state.prestigeCount += 1;
        state.upgrades.forEach(function (u) { u.level = 0; });
        state.activeBoosts = [];

        global.Sound.playLevelUp();
        closeAllModals();
        if (global.UI && global.UI.updateStatsDisplay) global.UI.updateStatsDisplay();
        if (global.UIUpgrades && global.UIUpgrades.render) global.UIUpgrades.render();
      });
    }
  }

  /* ------------------------------------------------------------
     ACHIEVEMENTS MODAL
     ------------------------------------------------------------ */
  function renderAchievementsModal() {
    const container = document.getElementById('achievementsModalContent');
    const countBadge = document.getElementById('achievementsCountBadge');
    if (!container) return;

    const state = global.GameState.get();
    const unlockedCount = state.achievements.filter(function (a) { return a.unlocked; }).length;
    if (countBadge) countBadge.textContent = unlockedCount + ' / ' + state.achievements.length;

    container.innerHTML = '';
    state.achievements.forEach(function (ach) {
      const isCompleted = ach.current >= ach.target;
      const pct = Math.min(100, Math.floor((ach.current / ach.target) * 100));

      const card = document.createElement('div');
      card.className = 'nx-card';
      card.style.padding = '0.875rem';
      card.style.display = 'flex';
      card.style.alignItems = 'center';
      card.style.justifyContent = 'space-between';
      card.style.gap = '0.75rem';

      card.innerHTML = `
        <div style="flex: 1; min-width: 0;">
          <div style="display: flex; justify-content: space-between; font-size: 0.8125rem;">
            <strong style="color: #fff;">${ach.name}</strong>
            <span style="font-family: ui-monospace, monospace; color: #94a3b8; font-size: 0.75rem;">
              ${ach.current.toLocaleString()} / ${ach.target.toLocaleString()}
            </span>
          </div>
          <div style="font-size: 0.75rem; color: #94a3b8; margin: 2px 0 6px 0;">${ach.desc}</div>
          <div class="nx-progress" style="height: 0.35rem;">
            <div class="nx-progress-bar" style="background: ${ach.unlocked ? '#10b981' : '#f59e0b'}; width: ${pct}%;"></div>
          </div>
        </div>
        <button class="nx-btn ${ach.unlocked ? 'nx-btn-secondary' : isCompleted ? 'nx-btn-gold' : ''}" ${ach.unlocked || !isCompleted ? 'disabled' : ''}>
          ${ach.unlocked ? 'Claimed' : '+' + ach.rewardGems + ' Gems'}
        </button>
      `;

      const btn = card.querySelector('button');
      if (btn && isCompleted && !ach.unlocked) {
        btn.addEventListener('click', function () {
          ach.unlocked = true;
          state.astralGems += ach.rewardGems;
          global.Sound.playLevelUp();
          renderAchievementsModal();
          if (global.UI && global.UI.updateStatsDisplay) global.UI.updateStatsDisplay();
        });
      }

      container.appendChild(card);
    });
  }

  global.UIModals = {
    init: initModals,
    open: openModal,
    close: closeModal,
    closeAll: closeAllModals
  };
})(typeof window !== 'undefined' ? window : this);
