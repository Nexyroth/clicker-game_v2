/**
 * NEXYROTH CLICKER - PROCEDURAL SOUND ENGINE
 * Web Audio API - Zero audio files - 100% Offline
 */
(function (global) {
  'use strict';

  let ctx = null;
  let enabled = true;
  let volume = 0.5;

  function initCtx() {
    if (!ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        ctx = new AudioCtx();
      }
    }
    if (ctx && ctx.state === 'suspended') {
      ctx.resume();
    }
  }

  const Sound = {
    setEnabled: function (val) {
      enabled = !!val;
    },
    setVolume: function (val) {
      volume = Math.max(0, Math.min(1, val));
    },
    playClick: function (isCrit) {
      if (!enabled || volume <= 0) return;
      try {
        initCtx();
        if (!ctx) return;

        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const now = ctx.currentTime;

        osc.type = isCrit ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(isCrit ? 680 : 380, now);
        osc.frequency.exponentialRampToValueAtTime(isCrit ? 1200 : 180, now + (isCrit ? 0.12 : 0.06));

        const vol = volume * (isCrit ? 0.35 : 0.2);
        gain.gain.setValueAtTime(vol, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + (isCrit ? 0.14 : 0.08));

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + (isCrit ? 0.15 : 0.09));
      } catch (e) {
        // ignore
      }
    },
    playPurchase: function () {
      if (!enabled || volume <= 0) return;
      try {
        initCtx();
        if (!ctx) return;

        const now = ctx.currentTime;
        [440, 660, 880].forEach(function (freq, idx) {
          if (!ctx) return;
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          const t = now + idx * 0.04;
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, t);
          gain.gain.setValueAtTime(volume * 0.15, t);
          gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(t);
          osc.stop(t + 0.11);
        });
      } catch (e) {
        // ignore
      }
    },
    playLevelUp: function () {
      if (!enabled || volume <= 0) return;
      try {
        initCtx();
        if (!ctx) return;

        const notes = [523.25, 659.25, 783.99, 1046.50];
        const now = ctx.currentTime;
        notes.forEach(function (freq, idx) {
          if (!ctx) return;
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          const t = now + idx * 0.07;
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, t);
          gain.gain.setValueAtTime(volume * 0.25, t);
          gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(t);
          osc.stop(t + 0.26);
        });
      } catch (e) {
        // ignore
      }
    },
    playBossVictory: function () {
      if (!enabled || volume <= 0) return;
      try {
        initCtx();
        if (!ctx) return;

        const chords = [440, 554.37, 659.25, 880];
        const now = ctx.currentTime;
        chords.forEach(function (freq) {
          if (!ctx) return;
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(freq, now);
          gain.gain.setValueAtTime(volume * 0.18, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + 0.75);
        });
      } catch (e) {
        // ignore
      }
    },
    playError: function () {
      if (!enabled || volume <= 0) return;
      try {
        initCtx();
        if (!ctx) return;

        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(150, now);
        osc.frequency.linearRampToValueAtTime(100, now + 0.15);
        gain.gain.setValueAtTime(volume * 0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.16);
      } catch (e) {
        // ignore
      }
    }
  };

  global.Sound = Sound;
})(typeof window !== 'undefined' ? window : this);
