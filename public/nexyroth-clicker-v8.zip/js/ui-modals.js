/**
 * NEXYROTH CLICKER - UNIVERSAL MODAL SYSTEM CONTROLLER (v8.0)
 * - Settings Modal: Audio SFX, Volume, Giftcodes, Language VI/EN, Base64 Export/Import Save
 * - Gem Shop Modal: Potion Purchases & Permanent Perks (Shortcut G, 3)
 * - Skills Modal: 5 Branches including 🍀 Vận May with vertical connectors & infinite node
 * - Inventory & Relics Modal: 27 Relics, max 4 equipped, ⚡ Tự Trang Bị (Auto-Equip)
 * - Achievements Modal: 35 Achievements with active +0.5% buffs (+17.5% max)
 * - Prestige & Worlds Modal: 4 Worlds (⛩️ Thiên Giới Vĩnh Hằng), 18 Pets & Cú Đêm Vĩnh Cửu
 * - Stats Modal: Personal Records (Kỷ Lục Cá Nhân) & 4 Multipliers
 */
(function (global) {
  'use strict';

  let activeModal = null;

  function openModal(modalId) {
    const el = document.getElementById(modalId);
    if (!el) return;

    if (activeModal && activeModal !== el) {
      activeModal.classList.remove('is-open');
    }

    el.classList.add('is-open');
    activeModal = el;

    if (global.Sound) global.Sound.playModalOpen();

    // Render contents
    if (modalId === 'gemShopModal') renderGemShopContent();
    if (modalId === 'settingsModal') renderSettingsContent();
    if (modalId === 'skillsModal') renderSkillsContent();
    if (modalId === 'inventoryModal') renderInventoryContent();
    if (modalId === 'prestigeModal') renderPrestigeContent();
    if (modalId === 'achievementsModal') renderAchievementsContent();
    if (modalId === 'statsModal') renderStatsContent();
    if (modalId === 'dailyRewardModal' && global.DailyRewards) global.DailyRewards.render();
    if (modalId === 'cosmicEventModal' && global.CosmicEvents) global.CosmicEvents.render();
  }

  function closeModal(modalId) {
    let el = null;
    if (modalId) {
      el = document.getElementById(modalId);
    } else {
      el = activeModal;
    }

    if (el) {
      el.classList.remove('is-open');
      if (activeModal === el) activeModal = null;
      if (global.Sound) global.Sound.playModalClose();
    }
  }

  function formatDuration(seconds) {
    const s = Math.ceil(seconds);
    const m = Math.floor(s / 60);
    const rem = s % 60;
    return m + ':' + (rem < 10 ? '0' : '') + rem;
  }

  function updateBackpackBadge() {
    const state = global.GameState.get();
    let totalPotions = 0;
    if (state.potions) {
      Object.keys(state.potions).forEach(function (k) {
        totalPotions += (state.potions[k] || 0);
      });
    }

    const badge = document.getElementById('backpackBadgeCount');
    if (badge) badge.textContent = totalPotions;

    const dot = document.getElementById('mobileBackpackDot');
    if (dot) dot.style.display = totalPotions > 0 ? 'block' : 'none';
  }

  function handleRedeemCode(code) {
    const state = global.GameState.get();
    const isVi = global.I18n ? global.I18n.getLang() === 'vi' : true;

    if (!state.redeemedCodes) state.redeemedCodes = [];
    if (state.redeemedCodes.includes(code)) {
      return {
        success: false,
        message: isVi ? 'Bạn đã đổi mã này rồi!' : 'Code already redeemed!'
      };
    }

    let rewardGems = 0;
    let rewardShards = 0;
    let rewardPotionKey = null;

    if (code === 'TANTHU') {
      rewardGems = 50;
      rewardPotionKey = 'potion_x2';
    } else if (code === 'NEXYROTH') {
      rewardGems = 100;
      rewardShards = 50;
    } else if (code === 'COSMIC2026') {
      rewardGems = 80;
      rewardPotionKey = 'potion_auto_50ms';
    } else if (code === 'VOIDPOWER') {
      rewardGems = 150;
      rewardPotionKey = 'potion_x50';
    } else if (code === 'VIP999') {
      rewardGems = 200;
      rewardShards = 100;
      rewardPotionKey = 'potion_x100';
    } else if (code === 'V8RELEASE') {
      rewardGems = 300;
      rewardShards = 150;
      rewardPotionKey = 'potion_x100';
    } else {
      return {
        success: false,
        message: isVi ? 'Mã quà tặng không hợp lệ hoặc đã hết hạn.' : 'Invalid or expired code.'
      };
    }

    state.redeemedCodes.push(code);
    state.astralGems += rewardGems;
    state.astralShards += rewardShards;
    state.totalAstralShards += rewardShards;

    if (rewardPotionKey) {
      if (!state.potions) state.potions = {};
      state.potions[rewardPotionKey] = (state.potions[rewardPotionKey] || 0) + 1;
    }

    if (global.Sound) global.Sound.playAchievement();
    global.GameState.save();
    if (global.UICore) global.UICore.updateStatsDisplay();
    updateBackpackBadge();

    const giftDesc = isVi
      ? `Nhận thành công: +${rewardGems} 💎, +${rewardShards} Shards${rewardPotionKey ? ' và +1 Thuốc' : ''}!`
      : `Success: +${rewardGems} 💎, +${rewardShards} Shards${rewardPotionKey ? ' & 1 Potion' : ''}!`;

    return { success: true, message: giftDesc };
  }

  // =========================================================================
  // 1. SETTINGS CONTENT (with Base64 Export/Import)
  // =========================================================================
  function renderSettingsContent() {
    const container = document.getElementById('settingsModalContent');
    if (!container) return;

    const state = global.GameState.get();
    const lang = global.I18n ? global.I18n.getLang() : 'vi';
    const isVi = lang === 'vi';
    const isMuted = !state.settings.sfxEnabled;

    container.innerHTML = `
      <!-- Header Version Badge -->
      <div style="text-align: center; padding: 0.6rem; border-radius: 0.75rem; background: rgba(56,189,248,0.1); border: 1px solid rgba(56,189,248,0.3); margin-bottom: 0.875rem;">
        <span style="font-weight: 900; font-size: 0.9375rem; color: #38bdf8;">⚔️ NEXYROTH CLICKER RPG v8.0</span>
        <span style="font-size: 0.6875rem; color: #94a3b8; margin-left: 6px;">(Build 8.0 Hybrid Web/Offline)</span>
      </div>

      <!-- 1. Language Switcher -->
      <div class="setting-row" style="background: rgba(56,189,248,0.08); border-color: rgba(56,189,248,0.3); border-radius: 0.875rem; padding: 0.875rem;">
        <div>
          <div style="font-weight: 800; font-size: 0.9375rem; color: #fff; display: flex; align-items: center; gap: 0.4rem;">
            <span>🌐</span>
            <span>${isVi ? 'Ngôn Ngữ / Language' : 'Language / Ngôn Ngữ'}</span>
          </div>
          <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 0.2rem;">
            ${isVi ? 'Chọn ngôn ngữ giao diện (Mặc định: Tiếng Việt)' : 'Select interface language (Default: Vietnamese)'}
          </div>
        </div>
        <div style="display: flex; gap: 0.35rem; background: rgba(15,23,42,0.9); padding: 4px; border-radius: 0.625rem; border: 1px solid var(--nx-surface-border);">
          <button id="langViBtn" class="nx-btn ${isVi ? 'nx-btn-primary' : 'nx-btn-secondary'}" style="padding: 0.35rem 0.75rem; font-size: 0.8125rem; font-weight: 800;">
            🇻🇳 Tiếng Việt
          </button>
          <button id="langEnBtn" class="nx-btn ${!isVi ? 'nx-btn-primary' : 'nx-btn-secondary'}" style="padding: 0.35rem 0.75rem; font-size: 0.8125rem; font-weight: 800;">
            🇬🇧 English
          </button>
        </div>
      </div>

      <!-- 2. Audio & Mute Controls -->
      <div style="border-radius: 0.875rem; background: rgba(18,24,38,0.85); border: 1px solid ${isMuted ? 'rgba(244,63,94,0.4)' : 'rgba(56,189,248,0.3)'}; padding: 1rem; display: flex; flex-direction: column; gap: 0.875rem;">
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem;">
          <div>
            <div style="font-weight: 800; font-size: 0.9375rem; color: #fff; display: flex; align-items: center; gap: 0.4rem;">
              <span>${isMuted ? '🔇' : '🔊'}</span>
              <span>${isVi ? 'Âm Thanh & Tắt Tiếng (SFX)' : 'Sound & Mute Controls'}</span>
            </div>
            <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 0.15rem;">
              ${isVi ? 'Tiếng hiệu ứng khi chạm Lõi, nâng cấp và thăng cấp' : 'Audio cues for clicks, upgrades, and level-ups'}
            </div>
          </div>
          <button id="quickMuteBtn" class="nx-btn ${isMuted ? 'nx-btn-danger' : 'nx-btn-emerald'}" style="padding: 0.5rem 1rem; font-size: 0.8125rem; font-weight: 800;">
            ${isMuted ? (isVi ? '🔇 ĐÃ TẮT TIẾNG' : '🔇 MUTED') : (isVi ? '🔊 ÂM THANH: BẬT' : '🔊 SOUND: ON')}
          </button>
        </div>

        <div style="display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; padding-top: 0.65rem; border-top: 1px solid rgba(255,255,255,0.08);">
          <span style="font-size: 0.8125rem; color: #cbd5e1; font-weight: 700;">
            ${isVi ? 'Âm lượng tổng:' : 'Master Volume:'} <strong id="volDisplay" style="color: #38bdf8;">${Math.round((state.settings.sfxVolume || 0.5) * 100)}%</strong>
          </span>
          <input id="volumeSlider" type="range" min="0" max="1" step="0.05" value="${state.settings.sfxVolume !== undefined ? state.settings.sfxVolume : 0.5}" style="flex: 1; max-width: 200px; accent-color: #38bdf8; cursor: pointer; height: 6px;">
        </div>
      </div>

      <!-- 3. Redeem Giftcode -->
      <div style="border-radius: 0.875rem; background: linear-gradient(135deg, rgba(251,191,36,0.12) 0%, rgba(168,85,247,0.12) 100%); border: 1.5px solid rgba(251,191,36,0.45); padding: 1rem; display: flex; flex-direction: column; gap: 0.75rem;">
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 0.35rem;">
          <div style="font-weight: 800; font-size: 0.9375rem; color: #fbbf24; display: flex; align-items: center; gap: 0.4rem;">
            <span>🎁</span>
            <span>${isVi ? 'Nhập Mã Quà Tặng (Giftcode)' : 'Redeem Giftcode'}</span>
          </div>
          <span style="font-size: 0.6875rem; color: #94a3b8;">
            ${isVi ? 'Bấm vào mã gợi ý để điền nhanh' : 'Tap a code chip below to auto-fill'}
          </span>
        </div>

        <div style="display: flex; gap: 0.4rem; flex-wrap: wrap;">
          <button class="nx-code-chip" data-code="TANTHU" style="background: rgba(251,191,36,0.15); border: 1px solid rgba(251,191,36,0.4); color: #fbbf24; border-radius: 0.375rem; padding: 0.25rem 0.5rem; font-size: 0.75rem; font-family: ui-monospace, monospace; font-weight: 700; cursor: pointer;">
            + TANTHU
          </button>
          <button class="nx-code-chip" data-code="NEXYROTH" style="background: rgba(56,189,248,0.15); border: 1px solid rgba(56,189,248,0.4); color: #38bdf8; border-radius: 0.375rem; padding: 0.25rem 0.5rem; font-size: 0.75rem; font-family: ui-monospace, monospace; font-weight: 700; cursor: pointer;">
            + NEXYROTH
          </button>
          <button class="nx-code-chip" data-code="V8RELEASE" style="background: rgba(168,85,247,0.15); border: 1px solid rgba(168,85,247,0.4); color: #c084fc; border-radius: 0.375rem; padding: 0.25rem 0.5rem; font-size: 0.75rem; font-family: ui-monospace, monospace; font-weight: 700; cursor: pointer;">
            + V8RELEASE
          </button>
          <button class="nx-code-chip" data-code="VIP999" style="background: rgba(52,211,153,0.15); border: 1px solid rgba(52,211,153,0.4); color: #34d399; border-radius: 0.375rem; padding: 0.25rem 0.5rem; font-size: 0.75rem; font-family: ui-monospace, monospace; font-weight: 700; cursor: pointer;">
            + VIP999
          </button>
        </div>

        <div style="display: flex; gap: 0.5rem;">
          <input id="settingsCodeInput" type="text" placeholder="${isVi ? 'Nhập mã tại đây (VD: V8RELEASE)' : 'Enter code here (e.g. V8RELEASE)'}" style="flex: 1; padding: 0.65rem 0.875rem; border-radius: 0.5rem; background: #0b1120; border: 1.5px solid rgba(251,191,36,0.35); color: #fff; font-size: 0.875rem; font-family: ui-monospace, monospace; text-transform: uppercase; font-weight: 700; outline: none;">
          <button id="settingsCodeBtn" class="nx-btn nx-btn-gold" style="padding: 0.65rem 1.25rem; font-weight: 900; font-size: 0.875rem; flex-shrink: 0;">
            🎁 ${isVi ? 'Đổi Quà' : 'Redeem'}
          </button>
        </div>
        <div id="settingsCodeFeedback" style="display: none; font-size: 0.8125rem; font-weight: 700; padding: 0.5rem 0.75rem; border-radius: 0.5rem;"></div>
      </div>

      <!-- 4. Save Management: Base64 String Export / Import (UX Feature from v8.2) -->
      <div style="border-radius: 0.875rem; background: rgba(18,24,38,0.85); border: 1px solid rgba(168,85,247,0.35); padding: 1rem; display: flex; flex-direction: column; gap: 0.75rem;">
        <div style="font-weight: 800; font-size: 0.9375rem; color: #c084fc; display: flex; align-items: center; justify-content: space-between;">
          <span style="display: flex; align-items: center; gap: 0.4rem;">
            <span>💾</span>
            <span>${isVi ? 'Xuất / Nhập Save Bằng Mã Base64' : 'Base64 Save Export / Import'}</span>
          </span>
          <span style="font-size: 0.6875rem; color: #94a3b8;">${isVi ? 'Đồng bộ tiến trình đa thiết bị' : 'Cross-device sync'}</span>
        </div>
        <p style="font-size: 0.75rem; color: #94a3b8; margin: 0; line-height: 1.35;">
          ${isVi ? 'Sao chép đoạn mã Base64 dưới đây để lưu trữ hoặc dán mã vào để khôi phục tiến trình chơi game của bạn.' : 'Copy this base64 string to backup or paste your save code to restore progress.'}
        </p>
        <div style="display: flex; gap: 0.5rem;">
          <button id="btnGenBase64" class="nx-btn nx-btn-violet" style="padding: 0.45rem 0.9rem; font-size: 0.8125rem;">
            📥 ${isVi ? 'Tạo Mã Xuất' : 'Generate Export'}
          </button>
          <button id="btnCopyBase64" class="nx-btn nx-btn-secondary" style="padding: 0.45rem 0.9rem; font-size: 0.8125rem;">
            📋 ${isVi ? 'Sao Chép' : 'Copy'}
          </button>
        </div>
        <textarea id="saveBase64Area" rows="3" placeholder="${isVi ? 'Mã lưu Base64 sẽ hiển thị ở đây, hoặc dán mã save của bạn vào đây...' : 'Base64 save string will appear here, or paste your save here...'}" style="width: 100%; border-radius: 0.5rem; background: #0b1120; border: 1px solid rgba(168,85,247,0.3); color: #e2e8f0; font-family: ui-monospace, monospace; font-size: 0.6875rem; padding: 0.5rem; outline: none;"></textarea>
        <button id="btnApplyBase64" class="nx-btn nx-btn-emerald" style="padding: 0.5rem; font-size: 0.8125rem; font-weight: 800;">
          ⚡ ${isVi ? 'NẠP DỮ LIỆU TỪ MÃ TRÊN (IMPORT SAVE)' : 'IMPORT SAVE DATA'}
        </button>
      </div>

      <!-- 5. Display Toggles -->
      <div class="setting-row">
        <div>
          <div style="font-weight: 800; font-size: 0.875rem; color: #fff;">
            ${isVi ? 'Ký Hiệu Khoa Học' : 'Scientific Notation'}
          </div>
          <div style="font-size: 0.75rem; color: #94a3b8;">
            ${isVi ? 'Hiển thị dạng 1.25e9 thay vì 1.25 B' : 'Display numbers like 1.25e9 instead of 1.25 B'}
          </div>
        </div>
        <button id="toggleScientific" class="toggle-switch ${state.settings.scientificNotation ? 'is-active' : ''}">
          <span class="toggle-handle"></span>
        </button>
      </div>

      <div class="setting-row">
        <div>
          <div style="font-weight: 800; font-size: 0.875rem; color: #fff;">
            ${isVi ? 'Chữ Số Bay Khi Bấm' : 'Floating Numbers'}
          </div>
          <div style="font-size: 0.75rem; color: #94a3b8;">
            ${isVi ? 'Hiển thị số sát thương nhảy lên khi chạm Lõi' : 'Show floating damage numbers on core click'}
          </div>
        </div>
        <button id="toggleFloating" class="toggle-switch ${state.settings.floatingNumbers ? 'is-active' : ''}">
          <span class="toggle-handle"></span>
        </button>
      </div>

      <!-- 6. File Backup & Source ZIP -->
      <div style="border-top: 1px solid var(--nx-surface-border); padding-top: 0.875rem; display: flex; flex-direction: column; gap: 0.625rem;">
        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
          <button id="btnExportSaveJson" class="nx-btn nx-btn-secondary" style="flex: 1; padding: 0.5rem;">
            ${isVi ? '📥 Xuất File (.json)' : '📥 Export File (.json)'}
          </button>
          <button id="btnImportSaveJson" class="nx-btn nx-btn-secondary" style="flex: 1; padding: 0.5rem;">
            ${isVi ? '📤 Nhập File' : '📤 Import File'}
          </button>
        </div>
        <button id="btnSettingsExportZip" class="nx-btn nx-btn-primary" style="width: 100%; padding: 0.65rem; font-size: 0.875rem; font-weight: 800;">
          📦 ${isVi ? 'TẢI TOÀN BỘ MÃ NGUỒN GAME v8.0 (.ZIP)' : 'DOWNLOAD FULL SOURCE CODE v8.0 (.ZIP)'}
        </button>
      </div>

      <!-- 7. Danger Zone -->
      <div style="border-top: 1px solid rgba(244,63,94,0.3); padding-top: 0.75rem;">
        <button id="btnHardReset" class="nx-btn nx-btn-danger" style="width: 100%; font-size: 0.8125rem;">
          ⚠️ ${isVi ? 'XÓA TOÀN BỘ DỮ LIỆU (CHƠI LẠI TỪ ĐẦU)' : 'HARD RESET (WIPE ALL PROGRESS)'}
        </button>
      </div>
    `;

    // Bind Language Switches
    const btnVi = document.getElementById('langViBtn');
    const btnEn = document.getElementById('langEnBtn');
    if (btnVi) btnVi.onclick = function () { global.I18n.setLang('vi'); renderSettingsContent(); };
    if (btnEn) btnEn.onclick = function () { global.I18n.setLang('en'); renderSettingsContent(); };

    // Bind Quick Mute Button
    const muteBtn = document.getElementById('quickMuteBtn');
    if (muteBtn) {
      muteBtn.onclick = function () {
        if (global.Sound && global.Sound.toggleMute) {
          global.Sound.toggleMute();
        } else {
          state.settings.sfxEnabled = !state.settings.sfxEnabled;
          global.GameState.save();
        }
        renderSettingsContent();
      };
    }

    // Bind Volume Slider
    const volSlider = document.getElementById('volumeSlider');
    const volDisplay = document.getElementById('volDisplay');
    if (volSlider) {
      volSlider.oninput = function () {
        const val = parseFloat(volSlider.value);
        if (global.Sound && global.Sound.setVolume) {
          global.Sound.setVolume(val);
        } else {
          state.settings.sfxVolume = val;
          global.GameState.save();
        }
        if (volDisplay) volDisplay.textContent = Math.round(val * 100) + '%';
      };
    }

    // Bind Display Toggles
    const toggleSci = document.getElementById('toggleScientific');
    if (toggleSci) {
      toggleSci.onclick = function () {
        state.settings.scientificNotation = !state.settings.scientificNotation;
        global.GameState.save();
        renderSettingsContent();
        if (global.UICore && global.UICore.updateStatsDisplay) global.UICore.updateStatsDisplay();
      };
    }

    const toggleFloat = document.getElementById('toggleFloating');
    if (toggleFloat) {
      toggleFloat.onclick = function () {
        state.settings.floatingNumbers = !state.settings.floatingNumbers;
        global.GameState.save();
        renderSettingsContent();
      };
    }

    // Bind Code Chips & Giftcode
    container.querySelectorAll('.nx-code-chip').forEach(function (chip) {
      chip.onclick = function () {
        const code = chip.getAttribute('data-code');
        const codeInput = document.getElementById('settingsCodeInput');
        if (codeInput && code) {
          codeInput.value = code;
          codeInput.focus();
        }
      };
    });

    const codeBtn = document.getElementById('settingsCodeBtn');
    const codeInput = document.getElementById('settingsCodeInput');
    const codeFeedback = document.getElementById('settingsCodeFeedback');
    if (codeBtn && codeInput) {
      codeBtn.onclick = function () {
        const code = codeInput.value.trim().toUpperCase();
        if (!code) return;
        const result = handleRedeemCode(code);
        if (codeFeedback) {
          codeFeedback.style.display = 'block';
          codeFeedback.style.background = result.success ? 'rgba(16,185,129,0.2)' : 'rgba(239,68,68,0.2)';
          codeFeedback.style.color = result.success ? '#34d399' : '#f87171';
          codeFeedback.style.border = result.success ? '1px solid #10b981' : '1px solid #ef4444';
          codeFeedback.textContent = (result.success ? '✓ ' : '✗ ') + result.message;
          if (result.success) codeInput.value = '';
        }
      };
    }

    // Bind Base64 Export & Import
    const btnGenB64 = document.getElementById('btnGenBase64');
    const btnCopyB64 = document.getElementById('btnCopyBase64');
    const b64Area = document.getElementById('saveBase64Area');
    const btnApplyB64 = document.getElementById('btnApplyBase64');

    if (btnGenB64 && b64Area) {
      btnGenB64.onclick = function () {
        b64Area.value = global.GameState.exportBase64();
        if (global.Toast) global.Toast.show(isVi ? 'Đã tạo mã lưu thành công!' : 'Base64 code generated!', 'success');
      };
    }

    if (btnCopyB64 && b64Area) {
      btnCopyB64.onclick = function () {
        if (!b64Area.value) b64Area.value = global.GameState.exportBase64();
        navigator.clipboard.writeText(b64Area.value).then(function () {
          if (global.Toast) global.Toast.show(isVi ? 'Đã sao chép mã lưu vào clipboard!' : 'Copied save code to clipboard!', 'success');
        });
      };
    }

    if (btnApplyB64 && b64Area) {
      btnApplyB64.onclick = function () {
        const code = b64Area.value.trim();
        if (!code) {
          if (global.Toast) global.Toast.show(isVi ? 'Vui lòng dán mã lưu trước!' : 'Please paste a save code first!', 'warning');
          return;
        }
        const res = global.GameState.importBase64(code);
        if (res.success) {
          if (global.Toast) global.Toast.show(isVi ? '🎉 Nhập tiến trình thành công! Đang tải lại...' : '🎉 Save imported! Reloading...', 'success');
          setTimeout(function () { window.location.reload(); }, 600);
        } else {
          if (global.Toast) global.Toast.show(res.error, 'error');
        }
      };
    }

    // Bind File Export/Import
    const btnExpSave = document.getElementById('btnExportSaveJson');
    if (btnExpSave) {
      btnExpSave.onclick = function () {
        const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(state));
        const dlAnchor = document.createElement('a');
        dlAnchor.setAttribute('href', dataStr);
        dlAnchor.setAttribute('download', 'nexyroth_save_v8_' + Date.now() + '.json');
        dlAnchor.click();
      };
    }

    const btnImpSave = document.getElementById('btnImportSaveJson');
    if (btnImpSave) {
      btnImpSave.onclick = function () {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.onchange = function (e) {
          const file = e.target.files[0];
          if (!file) return;
          const reader = new FileReader();
          reader.onload = function (evt) {
            try {
              const parsed = JSON.parse(evt.target.result);
              if (parsed && typeof parsed.essence === 'number') {
                global.GameState.set(parsed);
                global.GameState.save();
                window.location.reload();
              }
            } catch (err) {
              if (global.Toast) global.Toast.show(isVi ? 'Tệp sao lưu không hợp lệ.' : 'Invalid save file format.', 'error');
            }
          };
          reader.readAsText(file);
        };
        input.click();
      };
    }

    const btnExpZip = document.getElementById('btnSettingsExportZip');
    if (btnExpZip && global.ZipExport) {
      btnExpZip.onclick = function () { global.ZipExport.download(); };
    }

    const btnReset = document.getElementById('btnHardReset');
    if (btnReset) {
      btnReset.onclick = function () {
        const confirmMsg = isVi
          ? 'CẢNH BÁO: Thao tác này sẽ xoá toàn bộ tiến trình và chơi lại từ đầu. Bạn có chắc chắn không?'
          : 'WARNING: This will wipe all game progress and restart from zero. Are you sure?';
        if (confirm(confirmMsg)) {
          global.GameState.reset();
          window.location.reload();
        }
      };
    }
  }

  // =========================================================================
  // 2. GEM SHOP CONTENT
  // =========================================================================
  function renderGemShopContent() {
    const container = document.getElementById('gemShopModalContent');
    if (!container) return;

    const state = global.GameState.get();
    const isVi = global.I18n ? global.I18n.getLang() === 'vi' : true;
    const potionMetas = global.GameState.getPotionMetadata ? global.GameState.getPotionMetadata() : [];

    let potionsHtml = '';
    potionMetas.forEach(function (p) {
      const owned = (state.potions && state.potions[p.id]) || 0;
      const activeDuration = (state.activePotions && state.activePotions[p.type]) || 0;
      const canAfford = state.astralGems >= p.costGems;
      const name = isVi ? p.nameVi : p.nameEn;
      const desc = isVi ? p.descVi : p.descEn;

      potionsHtml += `
        <div class="nx-card" style="padding: 0.875rem; border-color: ${activeDuration > 0 ? 'rgba(56,189,248,0.5)' : 'var(--nx-surface-border)'}; background: ${activeDuration > 0 ? 'rgba(8,47,73,0.3)' : 'rgba(18,24,38,0.85)'};">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 0.5rem; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 0.75rem;">
              <div style="width: 2.75rem; height: 2.75rem; border-radius: 0.625rem; background: rgba(56,189,248,0.12); display: flex; align-items: center; justify-content: center; font-size: 1.35rem; flex-shrink: 0; border: 1.5px solid rgba(56,189,248,0.3);">
                ${p.icon}
              </div>
              <div>
                <div style="display: flex; align-items: center; gap: 0.45rem; flex-wrap: wrap;">
                  <span style="font-weight: 800; font-size: 0.875rem; color: #fff;">${name}</span>
                  <span class="nx-badge" style="background: rgba(56,189,248,0.15); color: #38bdf8; font-size: 0.6875rem; font-weight: 800;">
                    ${isVi ? 'Balo: ' + owned : 'Bag: ' + owned}
                  </span>
                  ${activeDuration > 0 ? `
                    <span class="nx-badge nx-badge-emerald" style="font-size: 0.6875rem; font-weight: 800; animation: pulse 2s infinite;">
                      ${isVi ? '⏳ Đang chạy: ' : '⏳ Active: '}${formatDuration(activeDuration)}
                    </span>
                  ` : ''}
                </div>
                <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 0.2rem; line-height: 1.35;">
                  ${desc}
                </div>
              </div>
            </div>

            <div style="display: flex; align-items: center; gap: 0.4rem; margin-top: 0.25rem;">
              <button class="nx-btn ${canAfford ? 'nx-btn-gold' : 'nx-btn-disabled'}" style="padding: 0.4rem 0.75rem; font-size: 0.75rem;" onclick="UIModals.buyPotion('${p.id}', false)">
                💎 ${p.costGems} Gems
              </button>
              <button class="nx-btn ${canAfford ? 'nx-btn-emerald' : 'nx-btn-disabled'}" style="padding: 0.4rem 0.75rem; font-size: 0.75rem;" onclick="UIModals.buyPotion('${p.id}', true)">
                ⚡ ${isVi ? 'Dùng Ngay' : 'Use Now'}
              </button>
            </div>
          </div>
        </div>
      `;
    });

    let perksHtml = '';
    state.gemShopItems.forEach(function (item) {
      const canAfford = state.astralGems >= item.costGems;
      perksHtml += `
        <div class="nx-card" style="padding: 0.875rem; display: flex; align-items: center; justify-content: space-between; gap: 0.75rem;">
          <div style="min-width: 0;">
            <div style="font-size: 0.875rem; font-weight: 800; color: #fff;">${item.name}</div>
            <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 0.15rem;">${item.desc}</div>
          </div>
          <div>
            ${item.purchased
              ? `<span class="nx-badge nx-badge-cyan" style="font-size: 0.75rem; font-weight: 800;">${isVi ? 'ĐÃ SỞ HỮU' : 'PURCHASED'}</span>`
              : `<button class="nx-btn ${canAfford ? 'nx-btn-gold' : 'nx-btn-disabled'}" style="padding: 0.4rem 0.8rem;" onclick="UIModals.buyGemItem('${item.id}')">
                   💎 ${item.costGems} Gems
                 </button>`
              }
          </div>
        </div>
      `;
    });

    container.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: space-between; padding: 1rem; border-radius: 0.875rem; background: linear-gradient(135deg, rgba(251,191,36,0.15) 0%, rgba(56,189,248,0.12) 100%); border: 1.5px solid rgba(251,191,36,0.4);">
        <div>
          <div style="font-size: 0.75rem; text-transform: uppercase; color: #94a3b8; font-weight: 800;">
            ${isVi ? 'Số Dư Đá Quý Của Bạn' : 'Your Astral Gems'}
          </div>
          <div style="font-size: 1.5rem; font-weight: 900; color: #fbbf24; font-family: ui-monospace, monospace;">${state.astralGems} 💎</div>
        </div>
        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
          <button class="nx-btn nx-btn-primary" style="font-size: 0.75rem; padding: 0.45rem 0.85rem;" onclick="UIModals.open('inventoryModal')">
            🎒 ${isVi ? 'Mở Balo Vật Phẩm' : 'Open Backpack'}
          </button>
          <button class="nx-btn nx-btn-secondary" style="font-size: 0.75rem; padding: 0.45rem 0.85rem;" onclick="UIModals.open('dailyRewardModal')">
            🎁 ${isVi ? 'Quà Hàng Ngày' : 'Daily Free'}
          </button>
        </div>
      </div>

      <div style="margin-top: 0.875rem;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
          <div style="font-size: 0.8125rem; font-weight: 800; text-transform: uppercase; color: #38bdf8; display: flex; align-items: center; gap: 0.4rem;">
            <span>🧪</span>
            <span>${isVi ? 'Thuốc Có Thời Hạn (Auto 50ms & Nhân x2..x100)' : 'Timed Potions (Auto 50ms & Multipliers)'}</span>
          </div>
          <span style="font-size: 0.6875rem; color: #94a3b8;">${isVi ? '⏱️ Mỗi loại 5 phút · Cộng dồn thời gian & hệ số' : '⏱️ 5 mins each · Stacking duration & multipliers'}</span>
        </div>
        <div style="display: flex; flex-direction: column; gap: 0.625rem;">
          ${potionsHtml}
        </div>
      </div>

      <div style="margin-top: 1.25rem;">
        <div style="font-size: 0.8125rem; font-weight: 800; text-transform: uppercase; color: #fbbf24; margin-bottom: 0.5rem; display: flex; align-items: center; gap: 0.4rem;">
          <span>💎</span>
          <span>${isVi ? 'Nâng Cấp Vĩnh Viễn Bằng Đá Quý' : 'Permanent Astral Perks'}</span>
        </div>
        <div style="display: flex; flex-direction: column; gap: 0.625rem;">
          ${perksHtml}
        </div>
      </div>
    `;
  }

  function buyPotion(potionId, useImmediately) {
    const state = global.GameState.get();
    const metaList = global.GameState.getPotionMetadata ? global.GameState.getPotionMetadata() : [];
    const meta = metaList.find(function (m) { return m.id === potionId; });
    if (!meta) return;

    const isVi = global.I18n ? global.I18n.getLang() === 'vi' : true;
    if (state.astralGems < meta.costGems) {
      const msg = isVi ? `Bạn không đủ Đá Quý (Cần ${meta.costGems} 💎, hiện có ${state.astralGems} 💎)!` : `Not enough Gems!`;
      if (global.Toast) global.Toast.show(msg, 'warning');
      if (global.Sound) global.Sound.playError();
      return;
    }

    state.astralGems -= meta.costGems;
    if (!state.potions) state.potions = {};

    if (useImmediately) {
      if (!state.activePotions) state.activePotions = {};
      const cur = state.activePotions[meta.type] || 0;
      state.activePotions[meta.type] = cur + (meta.duration || 300);
      if (global.Toast) {
        const timeFormatted = formatDuration(state.activePotions[meta.type]);
        const msg = isVi ? `✨ Đã mua & kích hoạt ${meta.nameVi}! Thời gian hiệu lực: ${timeFormatted}` : `✨ Bought & activated ${meta.nameEn}! (${timeFormatted})`;
        global.Toast.show(msg, 'success');
      }
    } else {
      state.potions[potionId] = (state.potions[potionId] || 0) + 1;
      if (global.Toast) {
        const msg = isVi ? `🎒 Đã mua ${meta.nameVi} và cất vào Balo!` : `🎒 Purchased ${meta.nameEn} to Backpack!`;
        global.Toast.show(msg, 'info');
      }
    }

    if (global.Sound) global.Sound.playUpgrade();
    global.GameState.save();
    if (global.UICore) {
      global.UICore.updateStatsDisplay();
      if (global.UICore.updateActiveBuffs) global.UICore.updateActiveBuffs();
    }
    updateBackpackBadge();
    renderGemShopContent();
    renderInventoryContent();
  }

  function buyGemItem(itemId) {
    const state = global.GameState.get();
    const item = state.gemShopItems.find(function (i) { return i.id === itemId; });
    if (!item || item.purchased || state.astralGems < item.costGems) {
      if (global.Sound) global.Sound.playError();
      return;
    }

    state.astralGems -= item.costGems;
    item.purchased = true;

    if (global.Sound) global.Sound.playAchievement();
    global.GameState.save();
    if (global.UICore) global.UICore.updateStatsDisplay();
    renderGemShopContent();
    renderInventoryContent();
  }

  // =========================================================================
  // 3. SKILLS CONTENT (5 Branches with Connectors and Infinite Node)
  // =========================================================================
  function renderSkillsContent() {
    const container = document.getElementById('skillsModalContent');
    if (!container) return;

    const state = global.GameState.get();
    const isVi = global.I18n ? global.I18n.getLang() === 'vi' : true;

    const ptsBadge = document.getElementById('skillPointsBadge');
    if (ptsBadge) ptsBadge.textContent = state.skillPoints + (isVi ? ' Điểm Kỹ Năng' : ' SP Available');

    const branches = [
      { id: 'void', name: '🔮 HƯ KHÔNG (CLICK POWER)', color: '#a855f7' },
      { id: 'astral', name: '✨ TINH THỂ (PASSIVE CPS)', color: '#38bdf8' },
      { id: 'chrono', name: '⏳ THỜI GIAN (CRIT & SPEED)', color: '#e879f9' },
      { id: 'cosmos', name: '🌌 VŨ TRỤ (ASCENSION & EXP)', color: '#818cf8' },
      { id: 'luck', name: '🍀 VẬN MAY (BOSS, DROPS & OFFLINE)', color: '#10b981' }
    ];

    let fullHtml = `
      <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.75rem 1rem; border-radius: 0.75rem; background: rgba(129,140,248,0.1); border: 1px solid rgba(129,140,248,0.3); margin-bottom: 1rem;">
        <span style="font-weight: 800; font-size: 0.875rem; color: #818cf8;">
          ✨ ${isVi ? 'Điểm Kỹ Năng Hiện Có:' : 'Available Skill Points:'} <strong style="color: #fff; font-size: 1.1rem;">${state.skillPoints} SP</strong>
        </span>
        <span style="font-size: 0.6875rem; color: #94a3b8;">
          ${isVi ? 'Nhận 1 SP mỗi khi thăng cấp nhân vật' : 'Gain 1 SP on each character level-up'}
        </span>
      </div>
    `;

    branches.forEach(function (br) {
      const branchSkills = state.skills.filter(function (s) { return s.branch === br.id; });
      fullHtml += `
        <div style="margin-bottom: 1.25rem;">
          <div style="font-size: 0.8125rem; font-weight: 900; color: ${br.color}; text-transform: uppercase; margin-bottom: 0.6rem; display: flex; align-items: center; gap: 0.4rem;">
            <span>${br.name}</span>
          </div>
          <div style="display: flex; flex-direction: column; gap: 0;">
      `;

      branchSkills.forEach(function (s, idx) {
        const canUnlock = state.skillPoints >= s.costPoints && (!s.reqSkillId || state.skills.find(function (x) { return x.id === s.reqSkillId; }).unlocked);
        const prevSkill = s.reqSkillId ? state.skills.find(function (x) { return x.id === s.reqSkillId; }) : null;
        const isPrevUnlocked = !prevSkill || prevSkill.unlocked;

        if (idx > 0) {
          fullHtml += `<div class="skill-connector ${isPrevUnlocked ? 'unlocked' : 'locked'}"></div>`;
        }

        fullHtml += `
          <div class="nx-card" style="padding: 0.875rem; display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; border-color: ${s.unlocked ? br.color : 'var(--nx-surface-border)'}; background: ${s.unlocked ? 'rgba(15,23,42,0.85)' : 'rgba(15,23,42,0.5)'};">
            <div style="flex: 1; min-width: 0;">
              <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                <span style="font-weight: 800; font-size: 0.875rem; color: #fff;">${s.name}</span>
                ${s.isInfinite ? `<span class="nx-badge nx-badge-emerald" style="font-size: 0.6875rem;">Cấp ${s.level || 0} (Vô hạn)</span>` : ''}
                <span class="nx-badge" style="background: rgba(255,255,255,0.08); color: #94a3b8; font-size: 0.6875rem;">${s.costPoints} SP</span>
              </div>
              <div style="font-size: 0.75rem; color: #cbd5e1; margin-top: 0.25rem; line-height: 1.35;">
                ${s.description}
                ${s.isInfinite && s.level > 0 ? `<br><strong style="color: #34d399;">+${s.level * 5}% toàn bộ hệ số may mắn!</strong>` : ''}
              </div>
            </div>
            <div>
              ${s.isInfinite
                ? `<button class="nx-btn ${canUnlock ? 'nx-btn-emerald' : 'nx-btn-disabled'}" onclick="UIModals.upgradeInfiniteSkill('${s.id}')">
                     +1 Cấp (${s.costPoints} SP)
                   </button>`
                : (s.unlocked
                  ? `<span class="nx-badge nx-badge-emerald">${isVi ? 'ĐÃ MỞ' : 'UNLOCKED'}</span>`
                  : `<button class="nx-btn ${canUnlock ? 'nx-btn-primary' : 'nx-btn-disabled'}" onclick="UIModals.unlockSkill('${s.id}')">
                       ${isVi ? 'Mở Khóa' : 'Unlock'}
                     </button>`
                  )
              }
            </div>
          </div>
        `;
      });

      fullHtml += `
          </div>
        </div>
      `;
    });

    container.innerHTML = fullHtml;
  }

  function unlockSkill(skillId) {
    const state = global.GameState.get();
    const skill = state.skills.find(function (s) { return s.id === skillId; });
    if (!skill || skill.unlocked || state.skillPoints < skill.costPoints) return;

    if (skill.reqSkillId) {
      const req = state.skills.find(function (s) { return s.id === skill.reqSkillId; });
      if (!req || !req.unlocked) return;
    }

    state.skillPoints -= skill.costPoints;
    skill.unlocked = true;

    if (global.Sound) global.Sound.playUpgrade();
    global.GameState.save();
    global.UI.updateStatsDisplay();
    renderSkillsContent();
  }

  function upgradeInfiniteSkill(skillId) {
    const state = global.GameState.get();
    const skill = state.skills.find(function (s) { return s.id === skillId; });
    if (!skill || state.skillPoints < skill.costPoints) return;

    if (skill.reqSkillId) {
      const req = state.skills.find(function (s) { return s.id === skill.reqSkillId; });
      if (!req || !req.unlocked) return;
    }

    state.skillPoints -= skill.costPoints;
    skill.level = (skill.level || 0) + 1;
    skill.unlocked = true;

    if (global.Sound) global.Sound.playUpgrade();
    global.GameState.save();
    global.UI.updateStatsDisplay();
    renderSkillsContent();
  }

  // =========================================================================
  // 4. INVENTORY & RELICS (27 Relics, Limit 4, Auto-Equip)
  // =========================================================================
  let currentBackpackTab = 'potions';

  function setBackpackTab(tab) {
    currentBackpackTab = tab;
    renderInventoryContent();
  }

  function usePotion(potionId) {
    const state = global.GameState.get();
    if (!state.potions || (state.potions[potionId] || 0) <= 0) return;

    const metaList = global.GameState.getPotionMetadata ? global.GameState.getPotionMetadata() : [];
    const meta = metaList.find(function (m) { return m.id === potionId; });
    if (!meta) return;

    state.potions[potionId] -= 1;
    if (!state.activePotions) state.activePotions = {};
    const curTime = state.activePotions[meta.type] || 0;
    state.activePotions[meta.type] = curTime + (meta.duration || 300);

    const isVi = global.I18n ? global.I18n.getLang() === 'vi' : true;
    const name = isVi ? meta.nameVi : meta.nameEn;
    const timeFormatted = formatDuration(state.activePotions[meta.type]);

    if (global.Sound) global.Sound.playUpgrade();
    if (global.Toast) {
      global.Toast.show(isVi ? `✨ Đã sử dụng ${name}! Thời gian hiệu lực: ${timeFormatted}` : `✨ Activated ${name}! (${timeFormatted})`, 'success');
    }

    global.GameState.save();
    if (global.UICore) {
      global.UICore.updateStatsDisplay();
      if (global.UICore.updateActiveBuffs) global.UICore.updateActiveBuffs();
    }
    updateBackpackBadge();
    renderInventoryContent();
  }

  // Auto-Equip best 4 relics with normalized score
  function autoEquipRelics() {
    const state = global.GameState.get();
    const isVi = global.I18n ? global.I18n.getLang() === 'vi' : true;

    // Reset equipped on all
    state.relics.forEach(function (r) { r.equipped = false; });

    // Calculate score
    const scoredRelics = state.relics.map(function (r) {
      const clickB = r.clickBonus || 0;
      const cpsB = r.cpsBonus || 0;
      const critB = r.critBonus || 0;
      const bossB = r.bossDamageBonus || 0;
      const gemB = r.gemDropBonus || 0;
      const itemB = r.itemDropBonus || 0;
      const offB = r.offlineBonus || 0;

      const score = (clickB * 100) + (cpsB * 100) + (critB * 200) + (bossB * 80) + (gemB * 80) + (itemB * 80) + (offB * 60);
      return { relic: r, score: score };
    });

    // Sort descending
    scoredRelics.sort(function (a, b) { return b.score - a.score; });

    // Equip top 4
    for (let i = 0; i < Math.min(4, scoredRelics.length); i++) {
      scoredRelics[i].relic.equipped = true;
    }

    if (global.Sound) global.Sound.playAchievement();
    if (global.Toast) {
      global.Toast.show(isVi ? '⚡ Đã tự động trang bị 4 Cổ Vật mạnh nhất!' : '⚡ Auto-equipped best 4 Relics!', 'success');
    }

    global.GameState.save();
    global.UI.updateStatsDisplay();
    renderInventoryContent();
  }

  function renderInventoryContent() {
    const container = document.getElementById('inventoryModalContent');
    if (!container) return;

    const state = global.GameState.get();
    const isVi = global.I18n ? global.I18n.getLang() === 'vi' : true;
    const potionMetas = global.GameState.getPotionMetadata ? global.GameState.getPotionMetadata() : [];

    let totalPotionsCount = 0;
    if (state.potions) {
      Object.keys(state.potions).forEach(function (k) { totalPotionsCount += (state.potions[k] || 0); });
    }

    const equippedCount = state.relics.filter(function (r) { return r.equipped; }).length;
    const badge = document.getElementById('relicsEquippedBadge');
    if (badge) {
      badge.textContent = currentBackpackTab === 'potions' 
        ? `${totalPotionsCount} ${isVi ? 'Thuốc trong Balo' : 'Potions in Bag'}` 
        : `${equippedCount} / 4 ${isVi ? 'Đã Trang Bị' : 'Equipped'}`;
    }

    let tabBodyHtml = '';

    if (currentBackpackTab === 'potions') {
      let potionsListHtml = '';
      potionMetas.forEach(function (p) {
        const count = (state.potions && state.potions[p.id]) || 0;
        const activeTime = (state.activePotions && state.activePotions[p.type]) || 0;
        const name = isVi ? p.nameVi : p.nameEn;
        const desc = isVi ? p.descVi : p.descEn;

        potionsListHtml += `
          <div class="nx-card" style="padding: 0.875rem; border-color: ${activeTime > 0 ? 'rgba(56,189,248,0.5)' : (count > 0 ? 'rgba(56,189,248,0.3)' : 'var(--nx-surface-border)')}; background: ${activeTime > 0 ? 'rgba(8,47,73,0.3)' : 'rgba(18,24,38,0.85)'};">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 0.5rem; flex-wrap: wrap;">
              <div style="display: flex; align-items: center; gap: 0.75rem;">
                <div style="width: 3rem; height: 3rem; border-radius: 0.75rem; background: rgba(56,189,248,0.12); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; flex-shrink: 0; border: 1.5px solid rgba(56,189,248,0.3);">
                  ${p.icon}
                </div>
                <div>
                  <div style="display: flex; align-items: center; gap: 0.45rem; flex-wrap: wrap;">
                    <span style="font-weight: 800; font-size: 0.9375rem; color: #fff;">${name}</span>
                    <span class="nx-badge" style="background: ${count > 0 ? 'rgba(56,189,248,0.25)' : 'rgba(71,85,105,0.4)'}; color: ${count > 0 ? '#38bdf8' : '#94a3b8'}; font-weight: 800; font-size: 0.75rem;">
                      ${isVi ? 'Số lượng: ' : 'Owned: '}<strong>x${count}</strong>
                    </span>
                    ${activeTime > 0 ? `
                      <span class="nx-badge nx-badge-emerald" style="font-weight: 800; font-size: 0.6875rem; animation: pulse 2s infinite;">
                        ${isVi ? '⏳ Đang chạy: ' : '⏳ Active: '}${formatDuration(activeTime)}
                      </span>
                    ` : ''}
                  </div>
                  <div style="font-size: 0.75rem; color: #cbd5e1; margin-top: 0.25rem; line-height: 1.35;">
                    ${desc}
                  </div>
                </div>
              </div>

              <div>
                ${count > 0 ? `
                  <button class="nx-btn nx-btn-emerald" style="padding: 0.5rem 1.15rem; font-weight: 800; font-size: 0.8125rem;" onclick="UIModals.usePotion('${p.id}')">
                    ✨ ${isVi ? 'SỬ DỤNG (+5 PHÚT)' : 'USE (+5 MINS)'}
                  </button>
                ` : `
                  <button class="nx-btn nx-btn-gold" style="padding: 0.45rem 0.85rem; font-size: 0.75rem;" onclick="UIModals.buyPotion('${p.id}', false)">
                    💎 ${isVi ? 'Mua Tại Shop' : 'Buy in Shop'} (${p.costGems})
                  </button>
                `}
              </div>
            </div>
          </div>
        `;
      });

      tabBodyHtml = `
        <div style="display: flex; flex-direction: column; gap: 0.625rem;">
          ${potionsListHtml}
        </div>
      `;
    } else {
      // TAB 2: RELICS (27 Relics, Max 4 Equipped)
      let relicsHtml = '';
      state.relics.forEach(function (r) {
        relicsHtml += `
          <div class="nx-card" style="padding: 0.875rem; display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; border-color: ${r.equipped ? 'rgba(56,189,248,0.5)' : 'var(--nx-surface-border)'};">
            <div style="display: flex; align-items: center; gap: 0.75rem;">
              <div style="width: 2.75rem; height: 2.75rem; border-radius: 0.625rem; background: rgba(56,189,248,0.12); display: flex; align-items: center; justify-content: center; font-size: 1.25rem; border: 1px solid rgba(56,189,248,0.25);">
                🔮
              </div>
              <div>
                <div style="display: flex; align-items: center; gap: 0.4rem;">
                  <span style="font-weight: 800; font-size: 0.875rem; color: #fff;">${r.name}</span>
                  <span class="nx-badge nx-badge-gold" style="font-size: 0.625rem;">${r.rarity.toUpperCase()}</span>
                </div>
                <div style="font-size: 0.75rem; color: #38bdf8; margin-top: 0.15rem;">${r.effectDesc}</div>
              </div>
            </div>
            <div>
              <button class="nx-btn ${r.equipped ? 'nx-btn-secondary' : 'nx-btn-primary'}" onclick="UIModals.toggleRelic('${r.id}')">
                ${r.equipped ? (isVi ? 'Tháo Ra' : 'Unequip') : (isVi ? 'Trang Bị' : 'Equip')}
              </button>
            </div>
          </div>
        `;
      });

      tabBodyHtml = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; padding: 0.5rem 0.75rem; background: rgba(56,189,248,0.08); border-radius: 0.625rem; border: 1px solid rgba(56,189,248,0.2);">
          <span style="font-size: 0.8125rem; font-weight: 800; color: #38bdf8;">
            🔮 ${isVi ? 'Đang trang bị:' : 'Equipped:'} ${equippedCount} / 4 ${isVi ? 'Cổ Vật' : 'Relics'}
          </span>
          <button class="nx-btn nx-btn-emerald" style="padding: 0.35rem 0.85rem; font-size: 0.75rem; font-weight: 800;" onclick="UIModals.autoEquipRelics()">
            ⚡ ${isVi ? 'Tự Trang Bị 4 Món Mạnh Nhất' : 'Auto-Equip Top 4'}
          </button>
        </div>
        <div style="display: flex; flex-direction: column; gap: 0.625rem;">
          ${relicsHtml}
        </div>
      `;
    }

    container.innerHTML = `
      <div style="display: flex; gap: 0.5rem; margin-bottom: 0.875rem; border-bottom: 1px solid var(--nx-surface-border); padding-bottom: 0.65rem;">
        <button class="nx-btn ${currentBackpackTab === 'potions' ? 'nx-btn-primary' : 'nx-btn-secondary'}" style="flex: 1; padding: 0.55rem; font-weight: 800; font-size: 0.8125rem;" onclick="UIModals.setBackpackTab('potions')">
          🎒 ${isVi ? 'Túi Thuốc & Shop Gems' : 'Potions & Shop Items'} (${totalPotionsCount})
        </button>
        <button class="nx-btn ${currentBackpackTab === 'relics' ? 'nx-btn-primary' : 'nx-btn-secondary'}" style="flex: 1; padding: 0.55rem; font-weight: 800; font-size: 0.8125rem;" onclick="UIModals.setBackpackTab('relics')">
          🔮 ${isVi ? 'Hòm Cổ Vật' : 'Relic Vault'} (${equippedCount}/4)
        </button>
      </div>
      ${tabBodyHtml}
    `;
  }

  function toggleRelic(relicId) {
    const state = global.GameState.get();
    const relic = state.relics.find(function (r) { return r.id === relicId; });
    if (!relic) return;

    if (!relic.equipped) {
      const currentEquipped = state.relics.filter(function (r) { return r.equipped; }).length;
      if (currentEquipped >= 4) {
        const isVi = global.I18n ? global.I18n.getLang() === 'vi' : true;
        const limitMsg = isVi ? 'Bạn chỉ có thể trang bị tối đa 4 Cổ Vật cùng lúc.' : 'You can only equip up to 4 Relics at the same time.';
        if (global.Toast) global.Toast.show(limitMsg, 'warning');
        return;
      }
      relic.equipped = true;
    } else {
      relic.equipped = false;
    }

    if (global.Sound) global.Sound.playClick();
    global.GameState.save();
    global.UI.updateStatsDisplay();
    renderInventoryContent();
  }

  // =========================================================================
  // 5. ACHIEVEMENTS CONTENT (35 with Buffs)
  // =========================================================================
  function renderAchievementsContent() {
    const container = document.getElementById('achievementsModalContent');
    if (!container) return;

    const state = global.GameState.get();
    const isVi = global.I18n ? global.I18n.getLang() === 'vi' : true;
    const unlockedCount = state.achievements.filter(function (a) { return a.unlocked; }).length;
    const achBuffPercent = global.Bonuses ? global.Bonuses.getAchievementBuffPercent() : (unlockedCount * 0.5);

    const badge = document.getElementById('achievementsCountBadge');
    if (badge) badge.textContent = unlockedCount + ' / ' + state.achievements.length;

    let html = `
      <div style="padding: 0.75rem 1rem; border-radius: 0.75rem; background: linear-gradient(135deg, rgba(251,191,36,0.15) 0%, rgba(168,85,247,0.15) 100%); border: 1.5px solid rgba(251,191,36,0.4); margin-bottom: 1rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem;">
        <div>
          <div style="font-size: 0.75rem; text-transform: uppercase; color: #94a3b8; font-weight: 800;">
            ${isVi ? 'Hiệu Ứng Buff Từ Thành Tựu' : 'Active Achievement Buff'}
          </div>
          <div style="font-size: 1.25rem; font-weight: 900; color: #fbbf24;">
            +${achBuffPercent}% ${isVi ? 'Toàn Bộ Sản Lượng & CPS' : 'All Production & CPS'}
          </div>
        </div>
        <span class="nx-badge nx-badge-gold" style="font-size: 0.8125rem; padding: 0.35rem 0.75rem;">
          ${unlockedCount} / ${state.achievements.length} ${isVi ? 'Đã Mở' : 'Unlocked'}
        </span>
      </div>
    `;

    state.achievements.forEach(function (ach) {
      const isComplete = ach.current >= ach.target;
      const pct = Math.min(100, Math.floor((ach.current / ach.target) * 100));

      html += `
        <div class="nx-card" style="padding: 0.875rem; display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; margin-bottom: 0.5rem;">
          <div style="flex: 1; min-width: 0;">
            <div style="display: flex; align-items: center; gap: 0.5rem;">
              <span style="font-weight: 800; font-size: 0.875rem; color: #fff;">${ach.name}</span>
              <span style="font-size: 0.6875rem; color: #fbbf24; font-family: ui-monospace, monospace;">+${ach.rewardGems} Gems · (+0.5% Buff)</span>
            </div>
            <div style="font-size: 0.75rem; color: #94a3b8; margin: 0.2rem 0 0.4rem;">${ach.desc}</div>
            <div class="quest-progress-bar">
              <div class="quest-progress-fill" style="width: ${pct}%;"></div>
            </div>
          </div>
          <div>
            ${ach.unlocked
              ? `<span class="nx-badge nx-badge-emerald">${isVi ? 'ĐÃ NHẬN' : 'CLAIMED'}</span>`
              : (isComplete
                ? `<button class="nx-btn nx-btn-gold" onclick="UIModals.claimAchievement('${ach.id}')">${isVi ? 'Nhận' : 'Claim'}</button>`
                : `<span style="font-size: 0.6875rem; font-family: ui-monospace, monospace; color: #64748b;">${pct}%</span>`
              )}
          </div>
        </div>
      `;
    });

    container.innerHTML = html;
  }

  function claimAchievement(achId) {
    const state = global.GameState.get();
    const ach = state.achievements.find(function (a) { return a.id === achId; });
    if (!ach || ach.unlocked || ach.current < ach.target) return;

    ach.unlocked = true;
    state.astralGems += ach.rewardGems;

    if (global.Sound) global.Sound.playAchievement();
    global.GameState.save();
    global.UI.updateStatsDisplay();
    renderAchievementsContent();
  }

  // =========================================================================
  // 6. PRESTIGE & WORLDS MODAL (4 Worlds, 18 Pets)
  // =========================================================================
  let prestigeTab = 'ascension';

  function renderPrestigeContent() {
    const container = document.getElementById('prestigeModalContent');
    if (!container) return;

    const state = global.GameState.get();
    const isVi = global.I18n ? global.I18n.getLang() === 'vi' : true;
    const potentialShards = Math.floor(Math.sqrt(state.totalEssence / 1000000));
    const canPrestige = potentialShards > 0;
    const worlds = global.GameState.getWorlds ? global.GameState.getWorlds() : [];

    let tabContent = '';

    if (prestigeTab === 'ascension') {
      tabContent = `
        <div style="text-align: center; padding: 1rem 0.5rem;">
          <div style="width: 70px; height: 70px; border-radius: 50%; background: rgba(168,85,247,0.15); border: 2px solid rgba(168,85,247,0.5); display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem;">
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#c084fc" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/></svg>
          </div>
          <h3 style="font-size: 1.25rem; font-weight: 800; color: #fff;">
            ${isVi ? 'Tái Sinh Vũ Trụ (Ascension)' : 'Astral Rebirth (Ascension)'}
          </h3>
          <p style="font-size: 0.8125rem; color: #94a3b8; max-width: 420px; margin: 0.5rem auto 1.25rem;">
            ${isVi 
              ? 'Hiến tế Năng Lượng và Nâng Cấp hiện tại để phi thăng lên cõi giới cao hơn, nhận Mảnh Astral Shards vĩnh viễn (mỗi Mảnh tăng +1% toàn bộ sản lượng).'
              : 'Sacrifice current Essence and Upgrades to ascend into higher dimensions, gaining permanent Astral Shards.'}
          </p>

          <div style="display: flex; justify-content: center; gap: 1rem; margin-bottom: 1.5rem;">
            <div style="padding: 0.75rem 1.25rem; border-radius: 0.75rem; background: rgba(18,24,38,0.8); border: 1px solid var(--nx-surface-border);">
              <div style="font-size: 0.6875rem; color: #94a3b8; text-transform: uppercase;">
                ${isVi ? 'Shards Hiện Có' : 'Current Shards'}
              </div>
              <div style="font-size: 1.25rem; font-weight: 900; color: #818cf8; font-family: ui-monospace, monospace;">${state.astralShards}</div>
            </div>
            <div style="padding: 0.75rem 1.25rem; border-radius: 0.75rem; background: rgba(168,85,247,0.12); border: 1px solid rgba(168,85,247,0.4);">
              <div style="font-size: 0.6875rem; color: #c084fc; text-transform: uppercase;">
                ${isVi ? 'Nhận Khi Tái Sinh' : 'Ascension Yield'}
              </div>
              <div style="font-size: 1.25rem; font-weight: 900; color: #c084fc; font-family: ui-monospace, monospace;">+${potentialShards} Shards</div>
            </div>
          </div>

          <button class="nx-btn ${canPrestige ? 'nx-btn-violet' : 'nx-btn-disabled'}" style="padding: 0.75rem 2rem; font-size: 0.875rem;" onclick="UIModals.executePrestige()">
            ${canPrestige 
              ? (isVi ? 'Phi Thăng & Nhận +' + potentialShards + ' Shards' : 'Ascend & Gain +' + potentialShards + ' Shards')
              : (isVi ? 'Cần tối thiểu 1,000,000 Tổng Năng Lượng' : 'Requires 1,000,000 Total Essence')}
          </button>
        </div>
      `;
    } else {
      // WORLDS & PETS TAB (4 Worlds, 18 Pets)
      let worldsHtml = '';
      worlds.forEach(function (w) {
        const isUnlocked = state.prestigeCount >= w.reqAscension;
        worldsHtml += `
          <div class="nx-card" style="padding: 0.875rem; border-color: ${isUnlocked ? 'rgba(56,189,248,0.4)' : 'var(--nx-surface-border)'}; background: ${isUnlocked ? 'rgba(15,23,42,0.8)' : 'rgba(15,23,42,0.4)'}; margin-bottom: 0.625rem;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <div>
                <div style="font-weight: 800; font-size: 0.9375rem; color: #fff;">${w.name}</div>
                <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 0.2rem;">${w.desc}</div>
                <div style="font-size: 0.6875rem; color: #fbbf24; margin-top: 0.2rem;">Tiền tệ riêng: ${w.currency}</div>
              </div>
              <div>
                ${isUnlocked 
                  ? `<span class="nx-badge nx-badge-emerald">ĐÃ MỞ KHÓA</span>`
                  : `<span class="nx-badge" style="background: rgba(244,63,94,0.2); color: #f43f5e;">Cần Thăng Thiên ${w.reqAscension} lần</span>`}
              </div>
            </div>
          </div>
        `;
      });

      // Pet Night Owl Showcase
      const owlLevel = (state.pets && state.pets.night_owl && state.pets.night_owl.level) || 0;
      worldsHtml += `
        <div style="margin-top: 1rem; padding: 0.875rem; border-radius: 0.75rem; background: rgba(16,185,129,0.1); border: 1px solid rgba(16,185,129,0.3);">
          <div style="font-weight: 800; font-size: 0.875rem; color: #34d399; display: flex; align-items: center; justify-content: space-between;">
            <span>🦉 Thần Thú Gacha 5: Cú Đêm Vĩnh Cửu</span>
            <span class="nx-badge nx-badge-emerald">Cấp ${owlLevel} (+${owlLevel * 5}% Offline)</span>
          </div>
          <div style="font-size: 0.75rem; color: #cbd5e1; margin-top: 0.25rem;">
            Tăng +5% Hiệu Suất Ngoại Tuyến mỗi cấp! Mở khóa và nhận trong Sự Kiện hoặc Gacha.
          </div>
        </div>
      `;

      tabContent = worldsHtml;
    }

    container.innerHTML = `
      <div style="display: flex; gap: 0.5rem; margin-bottom: 0.875rem; border-bottom: 1px solid var(--nx-surface-border); padding-bottom: 0.65rem;">
        <button class="nx-btn ${prestigeTab === 'ascension' ? 'nx-btn-violet' : 'nx-btn-secondary'}" style="flex: 1; padding: 0.55rem; font-weight: 800; font-size: 0.8125rem;" onclick="UIModals.setPrestigeTab('ascension')">
          🌌 ${isVi ? 'Tái Sinh Vũ Trụ' : 'Astral Rebirth'}
        </button>
        <button class="nx-btn ${prestigeTab === 'worlds' ? 'nx-btn-violet' : 'nx-btn-secondary'}" style="flex: 1; padding: 0.55rem; font-weight: 800; font-size: 0.8125rem;" onclick="UIModals.setPrestigeTab('worlds')">
          ⛩️ ${isVi ? '4 Thế Giới & Thú Cưng' : '4 Worlds & Pets'}
        </button>
      </div>
      ${tabContent}
    `;
  }

  function setPrestigeTab(tab) {
    prestigeTab = tab;
    renderPrestigeContent();
  }

  function executePrestige() {
    const state = global.GameState.get();
    const potentialShards = Math.floor(Math.sqrt(state.totalEssence / 1000000));
    if (potentialShards <= 0) return;

    state.astralShards += potentialShards;
    state.totalAstralShards += potentialShards;
    state.prestigeCount++;

    state.essence = 0;
    state.totalEssence = 0;
    state.level = 1;
    state.currentExp = 0;
    state.maxExp = 100;
    state.upgrades.forEach(function (u) { u.level = 0; });

    if (global.Sound) global.Sound.playAchievement();
    global.GameState.save();
    closeModal('prestigeModal');
    global.UI.updateStatsDisplay();
    if (global.UIUpgrades) global.UIUpgrades.render();
  }

  // =========================================================================
  // 7. STATS & PERSONAL RECORDS CONTENT
  // =========================================================================
  function renderStatsContent() {
    const container = document.getElementById('statsModalContent');
    if (!container) return;

    const state = global.GameState.get();
    const isVi = global.I18n ? global.I18n.getLang() === 'vi' : true;
    const format = global.Numeric ? global.Numeric.format : function (n) { return Math.floor(n); };
    const bonuses = global.Bonuses ? global.Bonuses.getAllBonuses() : {};

    container.innerHTML = `
      <!-- 1. PERSONAL RECORDS (v8.0: KỶ LỤC CÁ NHÂN) -->
      <div style="border-radius: 0.875rem; background: linear-gradient(135deg, rgba(251,191,36,0.15) 0%, rgba(56,189,248,0.15) 100%); border: 1.5px solid rgba(251,191,36,0.4); padding: 1rem; margin-bottom: 1rem;">
        <div style="font-size: 0.8125rem; font-weight: 900; text-transform: uppercase; color: #fbbf24; margin-bottom: 0.65rem; display: flex; align-items: center; gap: 0.4rem;">
          <span>🏆</span>
          <span>${isVi ? 'KỶ LỤC CÁ NHÂN (PERSONAL RECORDS)' : 'PERSONAL RECORDS'}</span>
        </div>
        <div style="display: flex; flex-direction: column; gap: 0.45rem;">
          <div style="display: flex; justify-content: space-between; font-size: 0.8125rem; color: #cbd5e1;">
            <span>${isVi ? 'Nexyroth/giây (CPS) cao nhất từng đạt:' : 'Highest CPS ever achieved:'}</span>
            <strong style="color: #38bdf8; font-family: ui-monospace, monospace;">${format(state.records.highestCps || 0)}/s</strong>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 0.8125rem; color: #cbd5e1;">
            <span>${isVi ? 'Cú click lớn nhất (kể cả Chí Mạng):' : 'Highest single click ever:'}</span>
            <strong style="color: #fbbf24; font-family: ui-monospace, monospace;">+${format(state.records.highestClick || 0)}</strong>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 0.8125rem; color: #cbd5e1;">
            <span>${isVi ? 'Số lần bấm nhiều nhất trong 10 giây:' : 'Max clicks in 10-second window:'}</span>
            <strong style="color: #c084fc; font-family: ui-monospace, monospace;">${state.records.maxClicksIn10s || 0} lần</strong>
          </div>
        </div>
      </div>

      <!-- 2. 4 NEW MULTIPLIERS (v8.1) -->
      <div style="border-radius: 0.875rem; background: rgba(18,24,38,0.85); border: 1px solid var(--nx-surface-border); padding: 1rem; margin-bottom: 1rem;">
        <div style="font-size: 0.8125rem; font-weight: 900; text-transform: uppercase; color: #38bdf8; margin-bottom: 0.65rem;">
          ⚡ ${isVi ? 'HỆ SỐ CHIẾN ĐẤU & KINH TẾ (BONUSES ENGINE)' : 'CORE BONUSES & ECONOMY'}
        </div>
        <div style="display: flex; flex-direction: column; gap: 0.45rem;">
          <div style="display: flex; justify-content: space-between; font-size: 0.8125rem; color: #cbd5e1;">
            <span>${isVi ? 'Sát Thương Boss (nhân dồn):' : 'Boss Damage Multiplier:'}</span>
            <strong style="color: #f43f5e; font-family: ui-monospace, monospace;">x${bonuses.bossDamageMultiplier || 1.0}</strong>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 0.8125rem; color: #cbd5e1;">
            <span>${isVi ? 'Tỉ Lệ Rơi Item & Thuốc:' : 'Item Drop Rate:'}</span>
            <strong style="color: #38bdf8; font-family: ui-monospace, monospace;">${Math.round((bonuses.itemDropChance || 0.05) * 100)}%</strong>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 0.8125rem; color: #cbd5e1;">
            <span>${isVi ? 'Tỉ Lệ Rơi Kim Cương (Gems):' : 'Gem Drop Rate:'}</span>
            <strong style="color: #fbbf24; font-family: ui-monospace, monospace;">${Math.round((bonuses.gemDropChance || 0.03) * 100)}%</strong>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 0.8125rem; color: #cbd5e1;">
            <span>${isVi ? 'Hiệu Suất Ngoại Tuyến (Offline):' : 'Offline Earnings Efficiency:'}</span>
            <strong style="color: #10b981; font-family: ui-monospace, monospace;">${Math.round((bonuses.offlineEfficiency || 0.50) * 100)}% (tối đa 100%)</strong>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 0.8125rem; color: #cbd5e1;">
            <span>${isVi ? 'Buff từ Thành Tựu đã mở:' : 'Achievement Production Buff:'}</span>
            <strong style="color: #fbbf24; font-family: ui-monospace, monospace;">+${bonuses.achievementBuffPercent || 0}%</strong>
          </div>
        </div>
      </div>

      <!-- 3. LIFETIME RUNTIME STATS -->
      <div style="border-radius: 0.875rem; background: rgba(18,24,38,0.85); border: 1px solid var(--nx-surface-border); padding: 1rem;">
        <div style="font-size: 0.8125rem; font-weight: 900; text-transform: uppercase; color: #a855f7; margin-bottom: 0.65rem;">
          📊 ${isVi ? 'THỐNG KÊ TOÀN CÕI' : 'LIFETIME TOTALS'}
        </div>
        <div style="display: flex; flex-direction: column; gap: 0.4rem; font-size: 0.8125rem; color: #cbd5e1;">
          <div style="display: flex; justify-content: space-between;">
            <span>Tổng lần bấm Lõi:</span>
            <strong>${state.totalClicks}</strong>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span>Tổng cú đánh Chí Mạng:</span>
            <strong>${state.totalCrits || 0}</strong>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span>Tổng số Boss đã hạ:</span>
            <strong>${state.bossesDefeated}</strong>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span>Tổng số nâng cấp đã mua:</span>
            <strong>${state.totalUpgradesBought || 0}</strong>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span>Tổng số lần Thăng Thiên:</span>
            <strong>${state.prestigeCount}</strong>
          </div>
        </div>
      </div>
    `;
  }

  function init() {
    document.querySelectorAll('.nx-modal-backdrop').forEach(function (backdrop) {
      backdrop.addEventListener('click', function (e) {
        if (e.target === backdrop) {
          closeModal(backdrop.id);
        }
      });

      const closeBtns = backdrop.querySelectorAll('.nx-modal-close');
      closeBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
          closeModal(backdrop.id);
        });
      });
    });

    window.addEventListener('keydown', function (e) {
      const activeTag = document.activeElement ? document.activeElement.tagName.toLowerCase() : '';
      if (activeTag === 'input' || activeTag === 'textarea') return;

      if (e.key === 'Escape' || e.code === 'Escape') {
        if (activeModal) closeModal(activeModal.id);
      } else if (e.key === 'g' || e.key === 'G' || e.code === 'KeyG') {
        const gemModal = document.getElementById('gemShopModal');
        if (gemModal && gemModal.classList.contains('is-open')) {
          closeModal('gemShopModal');
        } else {
          openModal('gemShopModal');
        }
      } else if (e.key === 'b' || e.key === 'B' || e.code === 'KeyB') {
        const invModal = document.getElementById('inventoryModal');
        if (invModal && invModal.classList.contains('is-open')) {
          closeModal('inventoryModal');
        } else {
          openModal('inventoryModal');
        }
      }
    });

    const gemShopBtn = document.getElementById('headerGemShopBtn');
    if (gemShopBtn) gemShopBtn.onclick = function () { openModal('gemShopModal'); };

    const invBtn = document.getElementById('headerInventoryBtn');
    if (invBtn) invBtn.onclick = function () { openModal('inventoryModal'); };

    const settingsBtn = document.getElementById('headerSettingsBtn');
    if (settingsBtn) settingsBtn.onclick = function () { openModal('settingsModal'); };

    const dailyBtn = document.getElementById('headerDailyBtn');
    if (dailyBtn) dailyBtn.onclick = function () { openModal('dailyRewardModal'); };

    const eventBtn = document.getElementById('headerEventBtn');
    if (eventBtn) eventBtn.onclick = function () { openModal('cosmicEventModal'); };

    const langBtn = document.getElementById('headerLangBtn');
    if (langBtn) {
      langBtn.onclick = function () {
        const nextLang = global.I18n.getLang() === 'vi' ? 'en' : 'vi';
        global.I18n.setLang(nextLang);
      };
    }

    const headerMuteBtn = document.getElementById('headerMuteBtn');
    if (headerMuteBtn) {
      headerMuteBtn.onclick = function () {
        if (global.Sound && global.Sound.toggleMute) {
          global.Sound.toggleMute();
        }
      };
    }

    updateBackpackBadge();
  }

  global.UIModals = {
    init: init,
    open: openModal,
    close: closeModal,
    buyPotion: buyPotion,
    usePotion: usePotion,
    setBackpackTab: setBackpackTab,
    updateBackpackBadge: updateBackpackBadge,
    buyGemItem: buyGemItem,
    unlockSkill: unlockSkill,
    upgradeInfiniteSkill: upgradeInfiniteSkill,
    toggleRelic: toggleRelic,
    autoEquipRelics: autoEquipRelics,
    executePrestige: executePrestige,
    setPrestigeTab: setPrestigeTab,
    claimAchievement: claimAchievement,
    redeemCode: handleRedeemCode,
    renderStatsContent: renderStatsContent
  };
})(typeof window !== 'undefined' ? window : this);
