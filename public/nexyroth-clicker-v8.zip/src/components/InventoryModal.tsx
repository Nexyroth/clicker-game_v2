import React, { useEffect } from 'react';
import { Relic, RelicRarity } from '../types/game';
import { sound } from '../utils/audio';
import { X, ShieldCheck, Eye, Hourglass, Heart, Check, Shield } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  relics: Relic[];
  onToggleEquip: (relicId: string) => void;
}

const RARITY_COLORS: Record<RelicRarity, { text: string; bg: string; border: string }> = {
  common: { text: 'text-slate-300', bg: 'bg-slate-900', border: 'border-slate-700' },
  rare: { text: 'text-sky-300', bg: 'bg-sky-950/40', border: 'border-sky-500/40' },
  epic: { text: 'text-purple-300', bg: 'bg-purple-950/40', border: 'border-purple-500/40' },
  legendary: { text: 'text-amber-300', bg: 'bg-amber-950/40', border: 'border-amber-500/40' },
  cosmic: { text: 'text-fuchsia-300', bg: 'bg-fuchsia-950/40', border: 'border-fuchsia-500/40' },
};

const ICON_MAP: Record<string, React.FC<{ className?: string }>> = {
  eye: Eye,
  hourglass: Hourglass,
  heart: Heart,
  shield: Shield,
};

export const InventoryModal: React.FC<Props> = ({
  isOpen,
  onClose,
  relics,
  onToggleEquip,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const equippedCount = relics.filter((r) => r.equipped).length;

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-xl max-h-[90vh] flex flex-col bg-slate-900 border border-cyan-500/40 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between z-20 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-950/60 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="text-base font-bold text-cyan-300">Relic Vault & Inventory</span>
              <div className="text-[11px] text-slate-400">Socketed cosmic relics bestow passive dimensional powers</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-2.5 py-1 bg-cyan-950/40 border border-cyan-500/40 rounded-lg text-cyan-300 font-mono font-bold text-xs">
              Equipped: {equippedCount}/3
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100 flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-5 space-y-4">
          <div className="text-xs text-slate-400">
            You can equip up to 3 Relics at a time. Defeat Titans in the Boss Arena to discover rarer cosmic artifacts.
          </div>

          <div className="space-y-3">
            {relics.map((relic) => {
              const rarityStyle = RARITY_COLORS[relic.rarity] || RARITY_COLORS.common;
              const IconComp = ICON_MAP[relic.icon] || Shield;

              return (
                <div
                  key={relic.id}
                  className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 transition-all ${
                    relic.equipped
                      ? 'bg-cyan-950/30 border-cyan-500/50 shadow-sm'
                      : 'bg-slate-950/40 border-slate-800/80'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border ${rarityStyle.bg} ${rarityStyle.border} ${rarityStyle.text}`}>
                      <IconComp className="w-6 h-6" />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs md:text-sm font-bold text-slate-100 truncate">{relic.name}</span>
                        <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded border uppercase ${rarityStyle.bg} ${rarityStyle.border} ${rarityStyle.text}`}>
                          {relic.rarity}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 mt-0.5">{relic.effectDesc}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      if (!relic.equipped && equippedCount >= 3) {
                        sound.playError();
                      } else {
                        sound.playPurchase();
                        onToggleEquip(relic.id);
                      }
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold shrink-0 transition-all flex items-center gap-1.5 cursor-pointer active:scale-95 ${
                      relic.equipped
                        ? 'bg-cyan-600 text-white shadow-sm'
                        : equippedCount >= 3
                        ? 'bg-slate-800 text-slate-500 border border-slate-700/50 cursor-not-allowed'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600'
                    }`}
                  >
                    {relic.equipped ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Equipped</span>
                      </>
                    ) : (
                      <span>Equip</span>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
