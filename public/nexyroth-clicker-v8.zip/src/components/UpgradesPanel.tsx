import React, { useState } from 'react';
import { Upgrade } from '../types/game';
import { formatNumber, calculateUpgradeCost, calculateMaxAffordable } from '../utils/numeric';
import { useCosmicAudio } from '../hooks/useCosmicAudio';
import { 
  Zap, 
  Sparkles, 
  CloudLightning, 
  Flame, 
  Disc, 
  Atom, 
  Orbit, 
  Sun, 
  Clock, 
  Shield 
} from 'lucide-react';

interface Props {
  upgrades: Upgrade[];
  essence: number;
  playerLevel: number;
  scientificNotation: boolean;
  onBuyUpgrade: (upgradeId: string, count: number, totalCost: number) => void;
}

const ICON_MAP: Record<string, React.FC<{ className?: string }>> = {
  zap: Zap,
  sparkles: Sparkles,
  'cloud-lightning': CloudLightning,
  flame: Flame,
  disc: Disc,
  atom: Atom,
  orbit: Orbit,
  sun: Sun,
  clock: Clock,
  shield: Shield,
};

type MultiplierMode = 1 | 10 | 25 | 100 | 'MAX';

export const UpgradesPanel: React.FC<Props> = ({
  upgrades,
  essence,
  playerLevel,
  scientificNotation,
  onBuyUpgrade,
}) => {
  const [multiplier, setMultiplier] = useState<MultiplierMode>(1);
  const { playUpgrade, playError } = useCosmicAudio();

  const handleBuy = (upgrade: Upgrade) => {
    let countToBuy = 0;
    let cost = 0;

    if (multiplier === 'MAX') {
      const maxInfo = calculateMaxAffordable(upgrade.baseCost, upgrade.costMultiplier, upgrade.level, essence);
      countToBuy = maxInfo.count;
      cost = maxInfo.totalCost;
    } else {
      countToBuy = multiplier;
      cost = calculateUpgradeCost(upgrade.baseCost, upgrade.costMultiplier, upgrade.level, countToBuy);
    }

    if (countToBuy > 0 && essence >= cost) {
      playUpgrade(upgrade.unlockedAtLevel);
      onBuyUpgrade(upgrade.id, countToBuy, cost);
    } else {
      playError();
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
      {/* Header with multiplier segmented control */}
      <div className="p-3.5 border-b border-slate-800 bg-slate-950/40 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
            Upgrades
          </h2>
        </div>

        {/* Multiplier buttons */}
        <div className="flex items-center bg-slate-900 border border-slate-700/60 rounded-lg p-0.5 text-xs font-semibold">
          {([1, 10, 25, 100, 'MAX'] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => setMultiplier(mode)}
              className={`px-2 py-1 rounded transition-colors ${
                multiplier === mode
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {mode === 'MAX' ? 'MAX' : `${mode}x`}
            </button>
          ))}
        </div>
      </div>

      {/* Upgrades Scrollable List */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2.5">
        {upgrades.map((upg) => {
          const isUnlocked = playerLevel >= upg.unlockedAtLevel;
          const IconComp = ICON_MAP[upg.icon] || Zap;

          let countToBuy = 1;
          let cost = 0;
          let canAfford = false;

          if (multiplier === 'MAX') {
            const maxInfo = calculateMaxAffordable(upg.baseCost, upg.costMultiplier, upg.level, essence);
            countToBuy = maxInfo.count > 0 ? maxInfo.count : 1;
            cost = maxInfo.count > 0 ? maxInfo.totalCost : calculateUpgradeCost(upg.baseCost, upg.costMultiplier, upg.level, 1);
            canAfford = maxInfo.count > 0 && essence >= cost;
          } else {
            countToBuy = multiplier;
            cost = calculateUpgradeCost(upg.baseCost, upg.costMultiplier, upg.level, countToBuy);
            canAfford = essence >= cost;
          }

          const currentTotalBoost = upg.level * upg.baseEffect;
          const nextBoost = countToBuy * upg.baseEffect;

          if (!isUnlocked) {
            return (
              <div
                key={upg.id}
                className="p-3 rounded-xl bg-slate-950/40 border border-slate-800/60 flex items-center justify-between opacity-60 text-slate-500"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center">
                    <Shield className="w-5 h-5 text-slate-600" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-slate-400">Locked Conduit</div>
                    <div className="text-[11px] text-slate-500">Unlocks at Level {upg.unlockedAtLevel}</div>
                  </div>
                </div>
              </div>
            );
          }

          return (
            <div
              key={upg.id}
              className={`p-3 rounded-xl border transition-all ${
                canAfford
                  ? 'bg-slate-900/80 hover:bg-slate-850 border-slate-700/70 hover:border-cyan-500/40 shadow-sm'
                  : 'bg-slate-950/50 border-slate-800/60 opacity-80'
              }`}
            >
              <div className="flex items-center justify-between gap-3">
                {/* Left: Icon & Info */}
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
                    upg.effectType === 'click'
                      ? 'bg-amber-950/40 border-amber-500/30 text-amber-300'
                      : 'bg-cyan-950/40 border-cyan-500/30 text-cyan-300'
                  }`}>
                    <IconComp className="w-5 h-5" />
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs md:text-sm font-bold text-slate-100 truncate">
                        {upg.name}
                      </span>
                      <span className="text-[11px] font-mono font-semibold px-1.5 py-0.2 rounded bg-slate-800 text-cyan-300 shrink-0">
                        Lv.{upg.level}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-400 truncate mt-0.5">
                      {upg.effectType === 'click' ? 'Click: ' : 'CPS: '}
                      <span className="text-slate-200 font-mono">
                        +{formatNumber(currentTotalBoost, scientificNotation)}
                      </span>
                      <span className="text-emerald-400 font-mono ml-1 font-semibold">
                        (+{formatNumber(nextBoost, scientificNotation)})
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right: Buy Button */}
                <button
                  onClick={() => handleBuy(upg)}
                  disabled={!canAfford}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold shrink-0 transition-all flex flex-col items-end justify-center ${
                    canAfford
                      ? 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-[0_0_10px_rgba(6,182,212,0.35)] active:scale-95'
                      : 'bg-slate-800/80 text-slate-500 border border-slate-700/40 cursor-not-allowed'
                  }`}
                >
                  <span className="text-[10px] text-cyan-100/80 font-normal">
                    {multiplier === 'MAX' ? `Buy +${countToBuy}` : `Buy +${countToBuy}`}
                  </span>
                  <span className="font-mono font-extrabold text-xs">
                    {formatNumber(cost, scientificNotation)}
                  </span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
