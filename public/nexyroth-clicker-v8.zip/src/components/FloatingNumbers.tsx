import React from 'react';
import { FloatingNumberItem } from '../types/game';

interface Props {
  items: FloatingNumberItem[];
}

export const FloatingNumbers: React.FC<Props> = ({ items }) => {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-20">
      {items.map((item) => (
        <div
          key={item.id}
          className={`absolute text-sm md:text-base font-bold tracking-wider select-none animate-float-number tabular-nums ${
            item.isCrit
              ? 'text-amber-300 drop-shadow-[0_0_8px_rgba(251,191,36,0.8)] scale-110 z-30 font-extrabold'
              : 'text-sky-300 drop-shadow-[0_0_6px_rgba(56,189,248,0.7)]'
          }`}
          style={
            {
              left: `${item.x}px`,
              top: `${item.y}px`,
              '--scatter-x': `${item.scatterX}px`,
            } as React.CSSProperties
          }
        >
          {item.isCrit ? `★ ${item.value} CRIT!` : `+${item.value}`}
        </div>
      ))}
    </div>
  );
};
