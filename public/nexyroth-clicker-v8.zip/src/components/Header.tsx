import React from 'react';
import { formatNumber } from '../utils/numeric';
import { Sparkles, Gem, Disc, Cloud, Settings as SettingsIcon } from 'lucide-react';

interface Props {
  essence: number;
  astralShards: number;
  astralGems: number;
  scientificNotation: boolean;
  onOpenGemShop: () => void;
  onOpenSettings: () => void;
  onOpenDrive: () => void;
  isDriveConnected: boolean;
}

export const Header: React.FC<Props> = ({
  essence,
  astralShards,
  astralGems,
  scientificNotation,
  onOpenGemShop,
  onOpenSettings,
  onOpenDrive,
  isDriveConnected,
}) => {
  return (
    <header className="w-full h-16 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md px-4 flex items-center justify-between z-30 shrink-0 select-none">
      {/* Zone 1: Wordmark Brand */}
      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-fuchsia-600 p-0.5 shadow-md flex items-center justify-center">
          <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-cyan-400" />
          </div>
        </div>
        <div className="flex flex-col">
          <span className="font-extrabold text-base tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-sky-400 via-indigo-300 to-fuchsia-400">
            NEXYROTH
          </span>
          <span className="text-[10px] text-slate-400 tracking-widest font-mono uppercase">
            Phase 4 · Cosmic
          </span>
        </div>
      </div>

      {/* Zone 2: Resource Balances (Unboxed clean tabular display) */}
      <div className="hidden sm:flex items-center gap-4 lg:gap-6 text-xs md:text-sm font-semibold">
        {/* Cosmic Essence */}
        <div className="flex items-center gap-1.5" title="Cosmic Essence">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(56,189,248,0.8)]" />
          <span className="text-slate-400 text-xs hidden md:inline">Essence:</span>
          <span className="font-mono text-cyan-300 font-bold tabular-nums">
            {formatNumber(essence, scientificNotation)}
          </span>
        </div>

        {/* Astral Shards */}
        <div className="flex items-center gap-1.5" title="Astral Shards (Prestige)">
          <Disc className="w-3.5 h-3.5 text-indigo-400" />
          <span className="text-slate-400 text-xs hidden md:inline">Shards:</span>
          <span className="font-mono text-indigo-300 font-bold tabular-nums">
            {formatNumber(astralShards, scientificNotation)}
          </span>
        </div>

        {/* Astral Gems */}
        <div className="flex items-center gap-1.5" title="Astral Gems">
          <Gem className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-slate-400 text-xs hidden md:inline">Gems:</span>
          <span className="font-mono text-amber-300 font-bold tabular-nums">
            {astralGems.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Zone 3: Primary Actions */}
      <div className="flex items-center gap-2">
        {/* Gem Shop Button (with 'G' badge) */}
        <button
          onClick={onOpenGemShop}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-600/30 to-amber-500/20 hover:from-amber-600/40 hover:to-amber-500/30 border border-amber-500/40 text-amber-200 text-xs font-semibold transition-all shadow-sm active:scale-95"
          title="Open Gem Shop (Shortcut: G)"
        >
          <Gem className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden xs:inline">Gem Shop</span>
          <kbd className="hidden md:inline px-1 py-0.2 text-[10px] bg-amber-950/80 border border-amber-500/40 rounded text-amber-300 font-mono">
            G
          </kbd>
        </button>

        {/* Google Drive Cloud Save */}
        <button
          onClick={onOpenDrive}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-all active:scale-95 ${
            isDriveConnected
              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/40'
              : 'bg-slate-900 border-slate-700/60 text-slate-300 hover:bg-slate-800'
          }`}
          title="Google Drive Cloud Save"
        >
          <Cloud className={`w-3.5 h-3.5 ${isDriveConnected ? 'text-emerald-400' : 'text-slate-400'}`} />
          <span className="hidden sm:inline">Drive Sync</span>
        </button>

        {/* Settings */}
        <button
          onClick={onOpenSettings}
          className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700/60 text-slate-300 hover:text-slate-100 transition-all active:scale-95"
          title="Settings (Esc)"
          aria-label="Settings"
        >
          <SettingsIcon className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
