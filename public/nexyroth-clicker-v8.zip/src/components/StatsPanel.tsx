import React from 'react';
import { GameState } from '../types/game';
import { formatNumber } from '../utils/numeric';
import { 
  Trophy, 
  Swords, 
  Sparkles, 
  Zap, 
  Flame, 
  Activity, 
  ShieldCheck, 
  Compass, 
  BookOpen 
} from 'lucide-react';

interface Props {
  gameState: GameState;
  cps: number;
  clickPower: number;
  frenzyMultiplier: number;
  onOpenBoss: () => void;
  onOpenSkills: () => void;
  onOpenInventory: () => void;
  onOpenPrestige: () => void;
  onOpenAchievements: () => void;
}

export const StatsPanel: React.FC<Props> = ({
  gameState,
  cps,
  clickPower,
  frenzyMultiplier,
  onOpenBoss,
  onOpenSkills,
  onOpenInventory,
  onOpenPrestige,
  onOpenAchievements,
}) => {
  const expPercent = Math.min(100, Math.floor((gameState.currentExp / gameState.maxExp) * 100));

  return (
    <div className="flex flex-col h-full bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
      {/* Level & Astral EXP Bar */}
      <div className="p-4 border-b border-slate-800 bg-slate-950/40">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
              Level {gameState.level}
            </span>
            <span className="text-[11px] text-slate-400">Cosmic Traveler</span>
          </div>
          <span className="text-[11px] font-mono text-slate-400">
            {gameState.currentExp} / {gameState.maxExp} EXP ({expPercent}%)
          </span>
        </div>

        {/* Progress Bar */}
        <div className="nx-progress h-2 bg-slate-950">
          <div
            className="nx-progress-bar bg-gradient-to-r from-cyan-500 to-indigo-500"
            style={{ width: `${expPercent}%` }}
          />
        </div>

        {gameState.skillPoints > 0 && (
          <div className="mt-2 flex items-center justify-between text-xs bg-indigo-950/60 border border-indigo-500/40 rounded-lg px-2.5 py-1 text-indigo-200">
            <span>Skill Points: <strong className="text-cyan-300 font-mono">+{gameState.skillPoints}</strong></span>
            <button
              onClick={onOpenSkills}
              className="text-[11px] font-bold text-cyan-300 hover:underline cursor-pointer"
            >
              Allocate →
            </button>
          </div>
        )}
      </div>

      {/* Production Stats Summary */}
      <div className="p-4 border-b border-slate-800 grid grid-cols-2 gap-2 text-xs">
        <div className="p-2.5 rounded-xl bg-slate-950/50 border border-slate-800/80">
          <div className="flex items-center gap-1.5 text-slate-400 mb-1">
            <Zap className="w-3.5 h-3.5 text-sky-400" />
            <span className="text-[11px] uppercase tracking-wider font-semibold">Click Power</span>
          </div>
          <div className="text-sm font-bold font-mono text-sky-300">
            {formatNumber(clickPower * frenzyMultiplier, gameState.settings.scientificNotation)}
          </div>
        </div>

        <div className="p-2.5 rounded-xl bg-slate-950/50 border border-slate-800/80">
          <div className="flex items-center gap-1.5 text-slate-400 mb-1">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-[11px] uppercase tracking-wider font-semibold">Passive CPS</span>
          </div>
          <div className="text-sm font-bold font-mono text-cyan-300">
            {formatNumber(cps * frenzyMultiplier, gameState.settings.scientificNotation)}/s
          </div>
        </div>
      </div>

      {/* Active Boosts & Frenzy */}
      {gameState.activeBoosts.length > 0 && (
        <div className="px-4 py-2 border-b border-slate-800 bg-amber-950/20">
          <div className="text-[11px] font-bold text-amber-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>Active Astral Surges</span>
          </div>
          <div className="space-y-1.5">
            {gameState.activeBoosts.map((boost) => (
              <div key={boost.id} className="flex items-center justify-between text-xs text-amber-200">
                <span className="truncate">{boost.name} ({boost.multiplier}x)</span>
                <span className="font-mono font-bold">{boost.remainingSeconds}s</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Navigation Panels */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2">
        {/* Boss Arena */}
        <button
          onClick={onOpenBoss}
          className="w-full p-3 rounded-xl bg-slate-950/40 hover:bg-slate-850 border border-slate-800 hover:border-rose-500/40 text-left transition-all group flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-rose-950/40 border border-rose-500/30 flex items-center justify-center text-rose-400 group-hover:scale-105 transition-transform">
              <Swords className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-200 group-hover:text-rose-300">
                Boss Encounters
              </div>
              <div className="text-[11px] text-slate-400">
                Defeat Void Titans for Gems & Shards
              </div>
            </div>
          </div>
          <span className="text-xs text-slate-500 group-hover:text-slate-300">→</span>
        </button>

        {/* Skill Tree */}
        <button
          onClick={onOpenSkills}
          className="w-full p-3 rounded-xl bg-slate-950/40 hover:bg-slate-850 border border-slate-800 hover:border-indigo-500/40 text-left transition-all group flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-indigo-950/40 border border-indigo-500/30 flex items-center justify-center text-indigo-400 group-hover:scale-105 transition-transform">
              <Compass className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-200 group-hover:text-indigo-300">
                Astral Constellations
              </div>
              <div className="text-[11px] text-slate-400">
                Unlock branching passive talents
              </div>
            </div>
          </div>
          <span className="text-xs text-slate-500 group-hover:text-slate-300">→</span>
        </button>

        {/* Relic Vault / Inventory */}
        <button
          onClick={onOpenInventory}
          className="w-full p-3 rounded-xl bg-slate-950/40 hover:bg-slate-850 border border-slate-800 hover:border-cyan-500/40 text-left transition-all group flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition-transform">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-200 group-hover:text-cyan-300">
                Relic Vault (Backpack)
              </div>
              <div className="text-[11px] text-slate-400">
                Equip ancient cosmic artifacts
              </div>
            </div>
          </div>
          <span className="text-xs text-slate-500 group-hover:text-slate-300">→</span>
        </button>

        {/* Achievements */}
        <button
          onClick={onOpenAchievements}
          className="w-full p-3 rounded-xl bg-slate-950/40 hover:bg-slate-850 border border-slate-800 hover:border-amber-500/40 text-left transition-all group flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-950/40 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
              <Trophy className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-200 group-hover:text-amber-300">
                Achievements
              </div>
              <div className="text-[11px] text-slate-400">
                Claim Gem rewards for milestones
              </div>
            </div>
          </div>
          <span className="text-xs text-slate-500 group-hover:text-slate-300">→</span>
        </button>

        {/* Prestige / Ascension */}
        <button
          onClick={onOpenPrestige}
          className="w-full p-3 rounded-xl bg-gradient-to-r from-indigo-950/50 to-purple-950/50 hover:from-indigo-900/60 hover:to-purple-900/60 border border-indigo-500/40 text-left transition-all group flex items-center justify-between mt-2"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-purple-900/60 border border-purple-400/40 flex items-center justify-center text-purple-300 group-hover:scale-105 transition-transform">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-purple-200">
                Astral Rebirth (Ascension)
              </div>
              <div className="text-[11px] text-purple-300/80">
                Reset progress for permanent multiplier
              </div>
            </div>
          </div>
          <span className="text-xs text-purple-400 group-hover:text-purple-200">→</span>
        </button>
      </div>
    </div>
  );
};
